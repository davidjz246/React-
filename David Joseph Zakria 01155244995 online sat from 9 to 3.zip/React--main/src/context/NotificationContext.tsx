import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AppNotification } from '../types';
import { useAuth } from './AuthContext';
import { networkStore } from '../services/networkStore';

interface NotificationContextType {
  notifications: AppNotification[];
  unreadCount: number;
  toastNotification: AppNotification | null;
  dismissToast: () => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  clearAllNotifications: () => void;
  simulateNotification: (type?: 'friend_request' | 'like' | 'comment') => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, networkUsers } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [toastNotification, setToastNotification] = useState<AppNotification | null>(null);

  const loadNotifications = useCallback(() => {
    if (!user) {
      setNotifications([]);
      return;
    }
    const list = networkStore.getNotifications(user._id);
    setNotifications(list);
  }, [user?._id]);

  useEffect(() => {
    loadNotifications();

    // Listen to real-time custom events across tabs or local mutations
    const handleNotificationEvent = (e: Event) => {
      const customEvent = e as CustomEvent<AppNotification[]>;
      if (user) {
        const userNotifs = customEvent.detail.filter((n) => n.userId === user._id);
        setNotifications(userNotifs);

        // Check if there is a fresh unread notification that we haven't toasted
        const latest = userNotifs[0];
        if (latest && !latest.read) {
          setToastNotification(latest);
          // Auto dismiss toast after 6 seconds
          setTimeout(() => {
            setToastNotification((prev) => (prev?.id === latest.id ? null : prev));
          }, 6000);
        }
      }
    };

    window.addEventListener('oasis_notification_event', handleNotificationEvent);
    return () => {
      window.removeEventListener('oasis_notification_event', handleNotificationEvent);
    };
  }, [user?._id, loadNotifications]);

  const dismissToast = () => {
    setToastNotification(null);
  };

  const markAsRead = (id: string) => {
    networkStore.markNotificationRead(id);
    if (user) {
      const updated = networkStore.getNotifications(user._id);
      setNotifications(updated);
    }
    if (toastNotification?.id === id) {
      setToastNotification(null);
    }
  };

  const markAllAsRead = () => {
    if (!user) return;
    networkStore.markAllNotificationsRead(user._id);
    const updated = networkStore.getNotifications(user._id);
    setNotifications(updated);
    setToastNotification(null);
  };

  const deleteNotification = (id: string) => {
    networkStore.deleteNotification(id);
    if (user) {
      const updated = networkStore.getNotifications(user._id);
      setNotifications(updated);
    }
  };

  const clearAllNotifications = () => {
    if (!user) return;
    networkStore.clearNotifications(user._id);
    setNotifications([]);
    setToastNotification(null);
  };

  // Helper method for demo testing: trigger an interactive simulated notification from another network member
  const simulateNotification = (type: 'friend_request' | 'like' | 'comment' = 'like') => {
    if (!user) return;
    const otherUser = networkUsers.find((u) => u._id !== user._id) || {
      _id: 'user_marcus_vance',
      name: 'Marcus Vance',
      photo: '/src/assets/images/avatar_marcus_vance_1791362814254.jpg',
      handle: '@marcusvance',
    };

    let title = 'New Notification';
    let message = `${otherUser.name} interacted with your account.`;

    if (type === 'friend_request') {
      title = 'New Friend Request';
      message = `${otherUser.name} wants to connect with you on Oasis.`;
    } else if (type === 'like') {
      title = 'Publication Liked';
      message = `${otherUser.name} liked your latest design publication.`;
    } else if (type === 'comment') {
      title = 'New Comment';
      message = `${otherUser.name} commented: "Brilliant spatial composition and lighting!"`;
    }

    networkStore.addNotification({
      userId: user._id,
      actor: {
        _id: otherUser._id,
        name: otherUser.name,
        photo: otherUser.photo,
        handle: otherUser.handle,
      },
      type,
      title,
      message,
    });
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        toastNotification,
        dismissToast,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        clearAllNotifications,
        simulateNotification,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
