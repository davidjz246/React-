import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, FriendRequest } from '../types';
import { networkStore } from '../services/networkStore';
import { apiService, getStoredToken, setStoredToken, removeStoredToken, getStoredUser, setStoredUser } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  networkUsers: User[];
  friends: string[];
  friendRequests: FriendRequest[];
  receivedRequests: FriendRequest[];
  sentRequests: FriendRequest[];
  login: (email: string, pass: string) => Promise<void>;
  register: (data: {
    name: string;
    email: string;
    password: string;
    rePassword?: string;
    dateOfBirth?: string;
    gender?: string;
  }) => Promise<{ message: string }>;
  logout: () => void;
  changePassword: (password: string, newPassword: string) => Promise<void>;
  updateProfilePhoto: (file: File) => Promise<void>;
  removeProfilePhoto: () => void;
  sendFriendRequest: (toUserId: string) => void;
  cancelFriendRequest: (toUserId: string) => void;
  acceptFriendRequest: (requestId: string) => void;
  removeFriend: (toUserId: string) => void;
  getFriendshipState: (targetUserId: string) => 'none' | 'pending_sent' | 'pending_received' | 'friends';
  refreshUserData: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    return getStoredUser();
  });
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [networkUsers, setNetworkUsers] = useState<User[]>(() => networkStore.getUsers());
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>(() => networkStore.getFriendRequests());
  const [friends, setFriends] = useState<string[]>(() => (user ? networkStore.getFriendsOf(user._id) : []));

  const refreshUserData = () => {
    const allUsers = networkStore.getUsers();
    setNetworkUsers(allUsers);
    setFriendRequests(networkStore.getFriendRequests());
    if (user) {
      const refreshed = networkStore.getUserById(user._id);
      if (refreshed) {
        setUser(refreshed);
        setStoredUser(refreshed);
      }
      setFriends(networkStore.getFriendsOf(user._id));
    }
  };

  useEffect(() => {
    refreshUserData();
  }, [user?._id]);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const emailLower = email.toLowerCase().trim();

      // Strictly validate credentials through apiService
      const res = await apiService.login({ email: emailLower, password: pass });
      if (res.token) {
        setToken(res.token);
        setStoredToken(res.token);
      }

      // Sync with networkStore
      let currentNetworkUser = networkStore.getUserByEmail(emailLower);
      if (!currentNetworkUser) {
        // Register into network store with clean 0 counts and no default photo
        currentNetworkUser = networkStore.addUser({
          name: res.user?.name || emailLower.split('@')[0],
          email: emailLower,
          handle: '@' + (res.user?.handle?.replace('@', '') || emailLower.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '')),
          gender: res.user?.gender || 'female',
          bio: res.user?.bio || 'Oasis community member.',
          photo: res.user?.photo || undefined,
        });
      }

      setUser(currentNetworkUser);
      setStoredUser(currentNetworkUser);
      refreshUserData();
      return res;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: {
    name: string;
    email: string;
    password: string;
    rePassword?: string;
    dateOfBirth?: string;
    gender?: string;
  }) => {
    setIsLoading(true);
    try {
      const emailLower = data.email.toLowerCase().trim();

      // Remote & local registration with password
      await apiService.register(data);

      // Add to local network store (starts with 0 followers, 0 following, no profile pic)
      networkStore.addUser({
        name: data.name.trim(),
        email: emailLower,
        handle: '@' + data.name.toLowerCase().replace(/\s+/g, '').replace(/[^a-zA-Z0-9_]/g, ''),
        gender: data.gender || 'female',
        dateOfBirth: data.dateOfBirth,
        bio: 'New member on Oasis.',
        photo: undefined, // Fresh user has no profile pic!
      });

      refreshUserData();
      return { message: 'Account created successfully! Please sign in with your credentials.' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    removeStoredToken();
    setToken(null);
    setUser(null);
  };

  const changePassword = async (password: string, newPassword: string) => {
    setIsLoading(true);
    try {
      await apiService.changePassword({ password, newPassword });
      refreshUserData();
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfilePhoto = async (file: File) => {
    if (!user) return;
    setIsLoading(true);
    try {
      const base64Url = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const updated = networkStore.updateUser(user._id, { photo: base64Url });
      setUser(updated);
      setStoredUser(updated);
      refreshUserData();
    } finally {
      setIsLoading(false);
    }
  };

  const removeProfilePhoto = () => {
    if (!user) return;
    const updated = networkStore.updateUser(user._id, { photo: '' });
    setUser(updated);
    setStoredUser(updated);
    refreshUserData();
  };

  // Friend Request system
  const sendFriendRequest = (toUserId: string) => {
    if (!user || user._id === toUserId) return;
    networkStore.sendFriendRequest(user._id, toUserId);
    refreshUserData();
  };

  const cancelFriendRequest = (toUserId: string) => {
    if (!user) return;
    networkStore.cancelFriendRequest(user._id, toUserId);
    refreshUserData();
  };

  const acceptFriendRequest = (requestId: string) => {
    networkStore.acceptFriendRequest(requestId);
    refreshUserData();
  };

  const removeFriend = (toUserId: string) => {
    if (!user) return;
    networkStore.removeFriend(user._id, toUserId);
    refreshUserData();
  };

  const getFriendshipState = (targetUserId: string): 'none' | 'pending_sent' | 'pending_received' | 'friends' => {
    if (!user) return 'none';
    const isFriends = friends.includes(targetUserId);
    if (isFriends) return 'friends';

    const sent = friendRequests.find((r) => r.fromUserId === user._id && r.toUserId === targetUserId && r.status === 'pending');
    if (sent) return 'pending_sent';

    const received = friendRequests.find((r) => r.fromUserId === targetUserId && r.toUserId === user._id && r.status === 'pending');
    if (received) return 'pending_received';

    return 'none';
  };

  const receivedRequests = user ? friendRequests.filter((r) => r.toUserId === user._id && r.status === 'pending') : [];
  const sentRequests = user ? friendRequests.filter((r) => r.fromUserId === user._id && r.status === 'pending') : [];

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        networkUsers,
        friends,
        friendRequests,
        receivedRequests,
        sentRequests,
        login,
        register,
        logout,
        changePassword,
        updateProfilePhoto,
        removeProfilePhoto,
        sendFriendRequest,
        cancelFriendRequest,
        acceptFriendRequest,
        removeFriend,
        getFriendshipState,
        refreshUserData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
