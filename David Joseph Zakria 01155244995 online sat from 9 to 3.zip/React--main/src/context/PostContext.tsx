import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Post, Comment, ActiveView, User } from '../types';
import { networkStore } from '../services/networkStore';
import { useAuth } from './AuthContext';

interface PostContextType {
  posts: Post[];
  isLoading: boolean;
  isRefreshing: boolean;
  searchQuery: string;
  selectedPost: Post | null;
  viewedUser: User | null;
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  setSearchQuery: (query: string) => void;
  setSelectedPost: (post: Post | null) => void;
  setViewedUser: (user: User | null) => void;
  openUserProfile: (user: User) => void;
  loadPosts: (showLoader?: boolean) => Promise<void>;
  loadPostDetails: (postId: string) => Promise<Post | null>;
  createPost: (body: string, imageFile?: File | null, tag?: string) => Promise<Post>;
  updatePost: (postId: string, body: string, imageFile?: File | null, tag?: string | null) => Promise<void>;
  deletePost: (postId: string) => Promise<void>;
  sharePost: (post: Post) => Promise<void>;
  toggleLikePost: (postId: string) => void;
  toggleSavePost: (postId: string) => void;
  addComment: (postId: string, content: string) => Promise<Comment>;
  updateComment: (postId: string, commentId: string, content: string) => Promise<void>;
  deleteComment: (postId: string, commentId: string) => Promise<void>;
  feedPosts: Post[];
  trendingPosts: Post[];
  mediaPosts: Post[];
  savedPosts: Post[];
}

const PostContext = createContext<PostContextType | undefined>(undefined);

export const PostProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>(() => networkStore.getPosts());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [viewedUser, setViewedUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState<ActiveView>('feed');

  const loadPosts = useCallback(async (showLoader: boolean = true) => {
    if (showLoader) setIsLoading(true);
    else setIsRefreshing(true);
    try {
      const stored = networkStore.getPosts();
      setPosts(stored);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  const openUserProfile = (targetUser: User) => {
    if (user && (targetUser._id === user._id || targetUser.email === user.email)) {
      setActiveView('profile');
    } else {
      // Find latest user from networkStore
      const fresh = networkStore.getUserById(targetUser._id) || targetUser;
      setViewedUser(fresh);
      setActiveView('user-profile');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const loadPostDetails = async (postId: string): Promise<Post | null> => {
    const existing = posts.find((p) => p._id === postId);
    if (existing) {
      setSelectedPost(existing);
      return existing;
    }
    return null;
  };

  const createPost = async (body: string, imageFile?: File | null, tag?: string): Promise<Post> => {
    setIsLoading(true);
    const localImage = imageFile ? URL.createObjectURL(imageFile) : undefined;

    const newPost: Post = {
      _id: 'post_' + Date.now(),
      body,
      image: localImage,
      user: {
        _id: user?._id || 'user_anon',
        name: user?.name || 'Community Member',
        email: user?.email || '',
        handle: user?.handle || '@member',
        photo: user?.photo || undefined,
      },
      createdAt: new Date().toISOString(),
      comments: [],
      likesCount: 0,
      isLiked: false,
      isSaved: false,
      sharesCount: 0,
      tags: tag?.trim() ? [tag.trim().replace(/^#+/, '')] : [],
      aspectRatio: '16:9',
    };

    const updated = networkStore.addPost(newPost);
    setPosts(updated);
    setIsLoading(false);
    return newPost;
  };

  const updatePost = async (postId: string, body: string, imageFile?: File | null, tag?: string | null) => {
    const updatedImage = imageFile ? URL.createObjectURL(imageFile) : undefined;
    const updates: Partial<Post> = { body };
    if (updatedImage !== undefined) {
      updates.image = updatedImage;
    }
    if (tag !== undefined) {
      const cleanTopic = tag?.trim().replace(/^#+/, '');
      updates.tags = cleanTopic ? [cleanTopic] : [];
    }

    const updated = networkStore.updatePost(postId, updates);
    setPosts(updated);

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost((prev) => (prev ? { ...prev, ...updates } : null));
    }
  };

  const deletePost = async (postId: string) => {
    const updated = networkStore.deletePost(postId);
    setPosts(updated);

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost(null);
      setActiveView('feed');
    }
  };

  const sharePost = async (post: Post) => {
    if (!user) return;

    // 1. Increment sharesCount on original post
    setPosts((prev) => {
      const updated = prev.map((p) => {
        if (p._id === post._id) {
          return { ...p, sharesCount: (p.sharesCount || 0) + 1 };
        }
        return p;
      });
      networkStore.savePosts(updated);
      return updated;
    });

    if (selectedPost && selectedPost._id === post._id) {
      setSelectedPost((prev) => (prev ? { ...prev, sharesCount: (prev.sharesCount || 0) + 1 } : null));
    }

    // 2. Create a new shared post on current user's profile / feed
    const sharedPostBody = `Shared from @${post.user?.name || 'Member'}:\n\n${post.body}`;
    const newSharedPost: Post = {
      _id: 'post_share_' + Date.now(),
      body: sharedPostBody,
      image: post.image,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        handle: user.handle || '@member',
        photo: user.photo,
      },
      createdAt: new Date().toISOString(),
      comments: [],
      likesCount: 0,
      isLiked: false,
      isSaved: false,
      sharesCount: 0,
      tags: post.tags || [],
      aspectRatio: post.aspectRatio || '16:9',
    };

    const updatedWithShare = networkStore.addPost(newSharedPost);
    setPosts(updatedWithShare);

    // 3. Notify original author if different
    if (post.user?._id && post.user._id !== user._id) {
      networkStore.addNotification({
        userId: post.user._id,
        actor: {
          _id: user._id,
          name: user.name,
          photo: user.photo,
          handle: user.handle,
        },
        type: 'mention',
        title: 'Publication Shared',
        message: `${user.name} shared your publication.`,
        targetId: post._id,
      });
    }
  };

  const toggleLikePost = (postId: string) => {
    const targetPost = posts.find((p) => p._id === postId);
    const willLike = !targetPost?.isLiked;

    setPosts((prev) => {
      const updated = prev.map((p) => {
        if (p._id === postId) {
          const isLiked = !p.isLiked;
          const likesCount = isLiked ? (p.likesCount || 0) + 1 : Math.max(0, (p.likesCount || 0) - 1);
          return { ...p, isLiked, likesCount };
        }
        return p;
      });
      networkStore.savePosts(updated);
      return updated;
    });

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost((prev) => {
        if (!prev) return null;
        const isLiked = !prev.isLiked;
        const likesCount = isLiked ? (prev.likesCount || 0) + 1 : Math.max(0, (prev.likesCount || 0) - 1);
        return { ...prev, isLiked, likesCount };
      });
    }

    // Trigger real-time notification if liked
    if (willLike && targetPost?.user?._id && user && targetPost.user._id !== user._id) {
      networkStore.addNotification({
        userId: targetPost.user._id,
        actor: {
          _id: user._id,
          name: user.name,
          photo: user.photo,
          handle: user.handle,
        },
        type: 'like',
        title: 'Publication Liked',
        message: `${user.name} liked your publication.`,
        targetId: postId,
      });
    }
  };

  const toggleSavePost = (postId: string) => {
    setPosts((prev) => {
      const updated = prev.map((p) => {
        if (p._id === postId) {
          return { ...p, isSaved: !p.isSaved };
        }
        return p;
      });
      networkStore.savePosts(updated);
      return updated;
    });

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost((prev) => (prev ? { ...prev, isSaved: !prev.isSaved } : null));
    }
  };

  const addComment = async (postId: string, content: string): Promise<Comment> => {
    const newComment: Comment = {
      _id: 'comm_' + Date.now(),
      content,
      post: postId,
      createdAt: new Date().toISOString(),
      likesCount: 0,
      isLiked: false,
      commentCreator: {
        _id: user?._id || 'user_anon',
        name: user?.name || 'Member',
        photo: user?.photo || undefined,
        email: user?.email || '',
      },
    };

    setPosts((prev) => {
      const updated = prev.map((p) => {
        if (p._id === postId) {
          return {
            ...p,
            comments: [...(p.comments || []), newComment],
          };
        }
        return p;
      });
      networkStore.savePosts(updated);
      return updated;
    });

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost((prev) =>
        prev
          ? {
              ...prev,
              comments: [...(prev.comments || []), newComment],
            }
          : null
      );
    }

    // Trigger real-time notification for post author
    const targetPost = posts.find((p) => p._id === postId);
    if (targetPost?.user?._id && user && targetPost.user._id !== user._id) {
      networkStore.addNotification({
        userId: targetPost.user._id,
        actor: {
          _id: user._id,
          name: user.name,
          photo: user.photo,
          handle: user.handle,
        },
        type: 'comment',
        title: 'New Comment',
        message: `${user.name} replied: "${content.length > 50 ? content.slice(0, 50) + '...' : content}"`,
        targetId: postId,
      });
    }

    return newComment;
  };

  const updateComment = async (postId: string, commentId: string, content: string) => {
    setPosts((prev) => {
      const updated = prev.map((p) => {
        if (p._id === postId) {
          return {
            ...p,
            comments: p.comments.map((c) => (c._id === commentId ? { ...c, content } : c)),
          };
        }
        return p;
      });
      networkStore.savePosts(updated);
      return updated;
    });

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost((prev) =>
        prev
          ? {
              ...prev,
              comments: prev.comments.map((c) => (c._id === commentId ? { ...c, content } : c)),
            }
          : null
      );
    }
  };

  const deleteComment = async (postId: string, commentId: string) => {
    setPosts((prev) => {
      const updated = prev.map((p) => {
        if (p._id === postId) {
          return {
            ...p,
            comments: p.comments.filter((c) => c._id !== commentId),
          };
        }
        return p;
      });
      networkStore.savePosts(updated);
      return updated;
    });

    if (selectedPost && selectedPost._id === postId) {
      setSelectedPost((prev) =>
        prev
          ? {
              ...prev,
              comments: prev.comments.filter((c) => c._id !== commentId),
            }
          : null
      );
    }
  };

  // Dedicated post collections for each page
  const searchFilter = (p: Post) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      p.body?.toLowerCase().includes(q) ||
      p.user?.name?.toLowerCase().includes(q) ||
      p.tags?.some((t) => t.toLowerCase().includes(q))
    );
  };

  const feedPosts = posts.filter(searchFilter);

  // Trending posts (ranked by engagement score: likes + comments weight)
  const trendingPosts = [...posts]
    .filter(searchFilter)
    .sort((a, b) => (b.likesCount + (b.comments?.length || 0) * 2) - (a.likesCount + (a.comments?.length || 0) * 2));

  // Visual media posts only (posts with images)
  const mediaPosts = posts.filter((p) => !!p.image).filter(searchFilter);

  // Saved bookmarks
  const savedPosts = posts.filter((p) => p.isSaved).filter(searchFilter);

  return (
    <PostContext.Provider
      value={{
        posts,
        isLoading,
        isRefreshing,
        searchQuery,
        selectedPost,
        viewedUser,
        activeView,
        setActiveView,
        setSearchQuery,
        setSelectedPost,
        setViewedUser,
        openUserProfile,
        loadPosts,
        loadPostDetails,
        createPost,
        updatePost,
        deletePost,
        sharePost,
        toggleLikePost,
        toggleSavePost,
        addComment,
        updateComment,
        deleteComment,
        feedPosts,
        trendingPosts,
        mediaPosts,
        savedPosts,
      }}
    >
      {children}
    </PostContext.Provider>
  );
};

export const usePosts = () => {
  const context = useContext(PostContext);
  if (!context) {
    throw new Error('usePosts must be used within a PostProvider');
  }
  return context;
};
