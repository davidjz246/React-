export interface User {
  _id: string;
  name: string;
  email: string;
  photo?: string;
  gender?: string;
  dateOfBirth?: string;
  createdAt?: string;
  bio?: string;
  handle?: string;
  followersCount: number;
  followingCount: number;
}

export interface Comment {
  _id: string;
  content: string;
  commentCreator: {
    _id: string;
    name: string;
    photo?: string;
    email?: string;
  };
  post: string;
  createdAt: string;
  likesCount?: number;
  isLiked?: boolean;
}

export interface Post {
  _id: string;
  body: string;
  image?: string;
  user: {
    _id: string;
    name: string;
    photo?: string;
    email?: string;
    handle?: string;
  };
  createdAt: string;
  comments: Comment[];
  likesCount: number;
  isLiked?: boolean;
  isSaved?: boolean;
  sharesCount?: number;
  sharedBy?: string[];
  isShared?: boolean;
  tags?: string[];
  aspectRatio?: '16:9' | '4:3' | '1:1' | '9:16' | 'auto';
}

export interface FriendRequest {
  id: string;
  fromUserId: string;
  toUserId: string;
  status: 'pending' | 'accepted';
  createdAt: string;
}

export type NotificationType = 'friend_request' | 'friend_accept' | 'like' | 'comment' | 'mention' | 'share';

export interface AppNotification {
  id: string;
  userId: string; // recipient
  actor: {
    _id: string;
    name: string;
    photo?: string;
    handle?: string;
  };
  type: NotificationType;
  title: string;
  message: string;
  targetId?: string; // e.g. postId or requestId
  read: boolean;
  createdAt: string;
}

export type ActiveView = 
  | 'feed' 
  | 'trending' 
  | 'media' 
  | 'friends' 
  | 'saved' 
  | 'profile' 
  | 'user-profile' 
  | 'post-details';
