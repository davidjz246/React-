import { User, Post, FriendRequest, Comment, AppNotification } from '../types';

const USERS_STORAGE_KEY = 'oasis_network_users_v3';
const POSTS_STORAGE_KEY = 'oasis_network_posts_v3';
const FRIEND_REQUESTS_KEY = 'oasis_friend_requests_v3';
const FRIENDSHIPS_KEY = 'oasis_friendships_v3';
const NOTIFICATIONS_STORAGE_KEY = 'oasis_notifications_v3';

// Clean initial network creators - test accounts removed as requested
export const INITIAL_NETWORK_USERS: User[] = [];

export const INITIAL_POSTS: Post[] = [];

export const networkStore = {
  // Users
  getUsers(): User[] {
    try {
      const raw = localStorage.getItem(USERS_STORAGE_KEY);
      if (raw) {
        const users: User[] = JSON.parse(raw);
        // Clean out Elena Rostova and Marcus Vance permanently
        const filtered = users.filter(
          (u) =>
            u._id !== 'user_marcus_vance' &&
            u.email?.toLowerCase() !== 'marcus.v@studioarch.co' &&
            u._id !== 'user_elena_k' &&
            u.email?.toLowerCase() !== 'elena@societal.org' &&
            u.name !== 'Marcus Vance' &&
            u.name !== 'Elena Rostova'
        );
        if (filtered.length !== users.length) {
          localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(filtered));
        }
        return filtered;
      }
    } catch {}
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(INITIAL_NETWORK_USERS));
    return INITIAL_NETWORK_USERS;
  },

  saveUsers(users: User[]) {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  },

  getUserById(id: string): User | undefined {
    return this.getUsers().find((u) => u._id === id);
  },

  getUserByEmail(email: string): User | undefined {
    return this.getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());
  },

  addUser(userData: Omit<User, '_id' | 'followersCount' | 'followingCount'>): User {
    const users = this.getUsers();
    const existing = users.find((u) => u.email.toLowerCase() === userData.email.toLowerCase());
    if (existing) {
      return existing;
    }

    const newUser: User = {
      ...userData,
      _id: 'user_' + Date.now(),
      followersCount: 0,
      followingCount: 0,
      createdAt: new Date().toISOString(),
      // No profile photo by default
      photo: userData.photo || undefined,
    };

    const updated = [newUser, ...users];
    this.saveUsers(updated);
    return newUser;
  },

  updateUser(userId: string, updates: Partial<User>): User {
    const users = this.getUsers();
    let updatedUser: User | undefined;
    const updated = users.map((u) => {
      if (u._id === userId) {
        const merged = { ...u, ...updates };
        if ('photo' in updates && (!updates.photo || updates.photo === '')) {
          delete merged.photo;
        }
        updatedUser = merged;
        return updatedUser;
      }
      return u;
    });
    this.saveUsers(updated);

    // Sync updated avatar/name across all authored posts & comments
    const allPosts = this.getPosts().map((post) => {
      let modified = false;
      let newPost = { ...post };

      if (post.user && post.user._id === userId) {
        modified = true;
        newPost.user = {
          ...post.user,
          name: updatedUser?.name || post.user.name,
          photo: updatedUser?.photo || undefined,
        };
      }

      if (post.comments && post.comments.length > 0) {
        const newComments = post.comments.map((c) => {
          if (c.commentCreator && c.commentCreator._id === userId) {
            return {
              ...c,
              commentCreator: {
                ...c.commentCreator,
                name: updatedUser?.name || c.commentCreator.name,
                photo: updatedUser?.photo || undefined,
              },
            };
          }
          return c;
        });
        newPost.comments = newComments;
      }

      return newPost;
    });
    this.savePosts(allPosts);

    return updatedUser || this.getUserById(userId)!;
  },

  // Posts
  getPosts(): Post[] {
    try {
      const raw = localStorage.getItem(POSTS_STORAGE_KEY);
      if (raw) {
        const posts: Post[] = JSON.parse(raw);
        const filtered = posts
          .filter(
            (p) =>
              p.user?._id !== 'user_marcus_vance' &&
              p.user?.email?.toLowerCase() !== 'marcus.v@studioarch.co' &&
              p.user?._id !== 'user_elena_k' &&
              p.user?.email?.toLowerCase() !== 'elena@societal.org' &&
              p.user?.name !== 'Marcus Vance' &&
              p.user?.name !== 'Elena Rostova'
          )
          .map((p) => ({
            ...p,
            comments: (p.comments || []).filter(
              (c) =>
                c.commentCreator?._id !== 'user_marcus_vance' &&
                c.commentCreator?.email?.toLowerCase() !== 'marcus.v@studioarch.co' &&
                c.commentCreator?._id !== 'user_elena_k' &&
                c.commentCreator?.email?.toLowerCase() !== 'elena@societal.org' &&
                c.commentCreator?.name !== 'Marcus Vance' &&
                c.commentCreator?.name !== 'Elena Rostova'
            ),
          }));
        if (filtered.length !== posts.length) {
          localStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(filtered));
        }
        return filtered;
      }
    } catch {}
    localStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(INITIAL_POSTS));
    return INITIAL_POSTS;
  },

  savePosts(posts: Post[]) {
    localStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(posts));
  },

  addPost(post: Post): Post[] {
    const posts = [post, ...this.getPosts()];
    this.savePosts(posts);
    return posts;
  },

  deletePost(postId: string): Post[] {
    const posts = this.getPosts().filter((p) => p._id !== postId);
    this.savePosts(posts);

    // Permanently purge any notifications referencing this deleted post
    try {
      const allNotifs = this.getNotifications();
      const cleaned = allNotifs.filter((n) => n.targetId !== postId);
      if (cleaned.length !== allNotifs.length) {
        this.saveNotifications(cleaned);
      }
    } catch {}

    return posts;
  },

  deleteComment(postId: string, commentId: string): Post[] {
    const posts = this.getPosts().map((p) => {
      if (p._id === postId) {
        return {
          ...p,
          comments: (p.comments || []).filter((c) => c._id !== commentId),
        };
      }
      return p;
    });
    this.savePosts(posts);
    return posts;
  },

  toggleSharePost(
    postId: string,
    userId: string,
    userDetails?: { name?: string; photo?: string; handle?: string }
  ): { posts: Post[]; isShared: boolean; sharesCount: number } {
    let resultIsShared = false;
    let resultSharesCount = 0;

    const posts = this.getPosts().map((p) => {
      if (p._id === postId) {
        const sharedBy = p.sharedBy || [];
        const isAlreadyShared = sharedBy.includes(userId);
        let newSharedBy: string[];
        let newSharesCount: number;

        if (isAlreadyShared) {
          // Unshare - remove from profile
          newSharedBy = sharedBy.filter((id) => id !== userId);
          newSharesCount = Math.max(0, (p.sharesCount || 1) - 1);
          resultIsShared = false;
        } else {
          // Share - add to profile
          newSharedBy = [...sharedBy.filter((id) => id !== userId), userId];
          newSharesCount = (p.sharesCount || 0) + 1;
          resultIsShared = true;

          // Trigger real-time notification to original author
          if (p.user?._id && p.user._id !== userId && userDetails?.name) {
            this.addNotification({
              userId: p.user._id,
              actor: {
                _id: userId,
                name: userDetails.name,
                photo: userDetails.photo,
                handle: userDetails.handle,
              },
              type: 'share',
              title: 'Publication Shared',
              message: `${userDetails.name} shared your publication to their profile.`,
              targetId: postId,
            });
          }
        }

        resultSharesCount = newSharesCount;
        return {
          ...p,
          sharedBy: newSharedBy,
          sharesCount: newSharesCount,
        };
      }
      return p;
    });

    this.savePosts(posts);
    return { posts, isShared: resultIsShared, sharesCount: resultSharesCount };
  },

  updatePost(postId: string, updates: Partial<Post>): Post[] {
    const posts = this.getPosts().map((p) => {
      if (p._id === postId) {
        return { ...p, ...updates };
      }
      return p;
    });
    this.savePosts(posts);
    return posts;
  },

  // Friendships & Requests
  getFriendRequests(): FriendRequest[] {
    try {
      const raw = localStorage.getItem(FRIEND_REQUESTS_KEY);
      if (raw) {
        const reqs: FriendRequest[] = JSON.parse(raw);
        return reqs.filter(
          (r) =>
            r.fromUserId !== 'user_marcus_vance' &&
            r.toUserId !== 'user_marcus_vance' &&
            r.fromUserId !== 'user_elena_k' &&
            r.toUserId !== 'user_elena_k'
        );
      }
    } catch {}
    return [];
  },

  saveFriendRequests(reqs: FriendRequest[]) {
    localStorage.setItem(FRIEND_REQUESTS_KEY, JSON.stringify(reqs));
  },

  getFriendships(): Record<string, string[]> {
    try {
      const raw = localStorage.getItem(FRIENDSHIPS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        delete parsed['user_marcus_vance'];
        delete parsed['user_elena_k'];
        for (const k of Object.keys(parsed)) {
          parsed[k] = (parsed[k] || []).filter(
            (id: string) => id !== 'user_marcus_vance' && id !== 'user_elena_k'
          );
        }
        localStorage.setItem(FRIENDSHIPS_KEY, JSON.stringify(parsed));
        return parsed;
      }
    } catch {}
    const initial = {};
    localStorage.setItem(FRIENDSHIPS_KEY, JSON.stringify(initial));
    return initial;
  },

  saveFriendships(map: Record<string, string[]>) {
    localStorage.setItem(FRIENDSHIPS_KEY, JSON.stringify(map));
  },

  sendFriendRequest(fromUserId: string, toUserId: string) {
    if (fromUserId === toUserId) return;
    const reqs = this.getFriendRequests();
    const exists = reqs.find(
      (r) => (r.fromUserId === fromUserId && r.toUserId === toUserId) || (r.fromUserId === toUserId && r.toUserId === fromUserId)
    );
    if (!exists) {
      reqs.push({
        id: 'freq_' + Date.now(),
        fromUserId,
        toUserId,
        status: 'pending',
        createdAt: new Date().toISOString(),
      });
      this.saveFriendRequests(reqs);

      // Logical Follower increment
      const fromUser = this.getUserById(fromUserId);
      const toUser = this.getUserById(toUserId);
      if (fromUser) this.updateUser(fromUserId, { followingCount: (fromUser.followingCount || 0) + 1 });
      if (toUser) this.updateUser(toUserId, { followersCount: (toUser.followersCount || 0) + 1 });

      // Trigger real-time notification
      if (fromUser && toUser) {
        this.addNotification({
          userId: toUserId,
          actor: {
            _id: fromUser._id,
            name: fromUser.name,
            photo: fromUser.photo,
            handle: fromUser.handle,
          },
          type: 'friend_request',
          title: 'New Connection Request',
          message: `${fromUser.name} sent you a friend request.`,
          targetId: fromUserId,
        });
      }
    }
  },

  acceptFriendRequest(requestId: string) {
    const reqs = this.getFriendRequests();
    const req = reqs.find((r) => r.id === requestId);
    if (!req) return;

    const updatedReqs = reqs.filter((r) => r.id !== requestId);
    this.saveFriendRequests(updatedReqs);

    // Mutual friendship
    const friendships = this.getFriendships();
    const u1Friends = friendships[req.fromUserId] || [];
    const u2Friends = friendships[req.toUserId] || [];

    if (!u1Friends.includes(req.toUserId)) u1Friends.push(req.toUserId);
    if (!u2Friends.includes(req.fromUserId)) u2Friends.push(req.fromUserId);

    friendships[req.fromUserId] = u1Friends;
    friendships[req.toUserId] = u2Friends;
    this.saveFriendships(friendships);

    const toUser = this.getUserById(req.toUserId);
    const fromUser = this.getUserById(req.fromUserId);
    if (toUser) this.updateUser(req.toUserId, { followingCount: (toUser.followingCount || 0) + 1 });
    if (fromUser) this.updateUser(req.fromUserId, { followersCount: (fromUser.followersCount || 0) + 1 });

    // Trigger notification to original requester
    if (toUser && fromUser) {
      this.addNotification({
        userId: req.fromUserId,
        actor: {
          _id: toUser._id,
          name: toUser.name,
          photo: toUser.photo,
          handle: toUser.handle,
        },
        type: 'friend_accept',
        title: 'Friend Request Accepted',
        message: `${toUser.name} accepted your friend request! You are now connected.`,
        targetId: req.toUserId,
      });
    }
  },

  cancelFriendRequest(fromUserId: string, toUserId: string) {
    const reqs = this.getFriendRequests().filter(
      (r) => !(r.fromUserId === fromUserId && r.toUserId === toUserId)
    );
    this.saveFriendRequests(reqs);

    const fromUser = this.getUserById(fromUserId);
    const toUser = this.getUserById(toUserId);
    if (fromUser && fromUser.followingCount > 0) this.updateUser(fromUserId, { followingCount: fromUser.followingCount - 1 });
    if (toUser && toUser.followersCount > 0) this.updateUser(toUserId, { followersCount: toUser.followersCount - 1 });
  },

  removeFriend(userA: string, userB: string) {
    const friendships = this.getFriendships();
    if (friendships[userA]) friendships[userA] = friendships[userA].filter((id) => id !== userB);
    if (friendships[userB]) friendships[userB] = friendships[userB].filter((id) => id !== userA);
    this.saveFriendships(friendships);

    const uA = this.getUserById(userA);
    const uB = this.getUserById(userB);
    if (uA) {
      this.updateUser(userA, {
        followingCount: Math.max(0, uA.followingCount - 1),
        followersCount: Math.max(0, uA.followersCount - 1),
      });
    }
    if (uB) {
      this.updateUser(userB, {
        followingCount: Math.max(0, uB.followingCount - 1),
        followersCount: Math.max(0, uB.followersCount - 1),
      });
    }
  },

  getFriendsOf(userId: string): string[] {
    const friendships = this.getFriendships();
    return friendships[userId] || [];
  },

  // Real-Time Notifications
  getNotifications(userId?: string): AppNotification[] {
    try {
      const raw = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
      if (raw) {
        const list: AppNotification[] = JSON.parse(raw);
        const filtered = list.filter(
          (n) =>
            n.actor?._id !== 'user_marcus_vance' &&
            n.actor?.name !== 'Marcus Vance' &&
            n.actor?._id !== 'user_elena_k' &&
            n.actor?.name !== 'Elena Rostova' &&
            n.userId !== 'user_marcus_vance' &&
            n.userId !== 'user_elena_k'
        );
        if (userId) {
          return filtered.filter((n) => n.userId === userId);
        }
        return filtered;
      }
    } catch {}
    return [];
  },

  saveNotifications(notifs: AppNotification[]) {
    localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(notifs));
    // Dispatch custom event for real-time reactive sync across components
    window.dispatchEvent(new CustomEvent('oasis_notification_event', { detail: notifs }));
  },

  addNotification(data: {
    userId: string;
    actor: {
      _id: string;
      name: string;
      photo?: string;
      handle?: string;
    };
    type: 'friend_request' | 'friend_accept' | 'like' | 'comment' | 'mention' | 'share';
    title: string;
    message: string;
    targetId?: string;
  }): AppNotification {
    // Avoid self-notifications
    if (data.userId === data.actor._id) {
      return null as any;
    }

    const all = this.getNotifications();
    const newNotif: AppNotification = {
      id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: data.userId,
      actor: data.actor,
      type: data.type,
      title: data.title,
      message: data.message,
      targetId: data.targetId,
      read: false,
      createdAt: new Date().toISOString(),
    };

    const updated = [newNotif, ...all].slice(0, 100); // keep recent 100
    this.saveNotifications(updated);
    return newNotif;
  },

  markNotificationRead(notificationId: string): AppNotification[] {
    const all = this.getNotifications();
    const updated = all.map((n) => (n.id === notificationId ? { ...n, read: true } : n));
    this.saveNotifications(updated);
    return updated;
  },

  markAllNotificationsRead(userId: string): AppNotification[] {
    const all = this.getNotifications();
    const updated = all.map((n) => (n.userId === userId ? { ...n, read: true } : n));
    this.saveNotifications(updated);
    return updated;
  },

  deleteNotification(notificationId: string): AppNotification[] {
    const all = this.getNotifications();
    const updated = all.filter((n) => n.id !== notificationId);
    this.saveNotifications(updated);
    return updated;
  },

  clearNotifications(userId: string): AppNotification[] {
    const all = this.getNotifications();
    const updated = all.filter((n) => n.userId !== userId);
    this.saveNotifications(updated);
    return updated;
  },
};
