import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { PostProvider, usePosts } from './context/PostContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthScreen } from './components/AuthScreen';
import { Navbar } from './components/Navbar';
import { LeftSidebar } from './components/LeftSidebar';
import { RightSidebar } from './components/RightSidebar';
import { FeedView } from './components/FeedView';
import { TrendingView } from './components/TrendingView';
import { VisualMediaView } from './components/VisualMediaView';
import { FriendsView } from './components/FriendsView';
import { SavedPostsView } from './components/SavedPostsView';
import { ProfileView } from './components/ProfileView';
import { UserProfileView } from './components/UserProfileView';
import { PostDetailsView } from './components/PostDetailsView';
import { AuthModal } from './components/AuthModal';
import { CreatePostModal } from './components/CreatePostModal';
import { EditPostModal } from './components/EditPostModal';
import { LightboxModal } from './components/LightboxModal';
import { NotificationToast } from './components/NotificationToast';
import { Post } from './types';

const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const { activeView, setActiveView, selectedPost, setSelectedPost, viewedUser } = usePosts();

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'change-password'>('login');
  const [createPostModalOpen, setCreatePostModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // If not authenticated, show Facebook-style AuthScreen gateway
  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  const handleOpenAuth = (mode: 'login' | 'register' | 'change-password' = 'change-password') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleOpenDetails = (post: Post) => {
    setSelectedPost(post);
    setActiveView('post-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEditPost = (post: Post) => {
    setEditingPost(post);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors selection:bg-indigo-500/30 selection:text-indigo-400">
      {/* 1. Global Navigation Bar with Real-Time Notifications */}
      <Navbar
        onOpenAuth={handleOpenAuth}
        onOpenCreateModal={() => setCreatePostModalOpen(true)}
      />

      {/* Floating Real-Time Alert Toast */}
      <NotificationToast />

      {/* 2. Main Workspace Layout */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="flex flex-col lg:flex-row items-start justify-center gap-6 lg:gap-8">
          {/* Left Navigation Sidebar */}
          <LeftSidebar />

          {/* Dedicated View Components */}
          <div className="w-full max-w-2xl flex-1 min-w-0">
            {activeView === 'feed' && (
              <FeedView
                onOpenDetails={handleOpenDetails}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}

            {activeView === 'trending' && (
              <TrendingView
                onOpenDetails={handleOpenDetails}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}

            {activeView === 'media' && (
              <VisualMediaView
                onOpenDetails={handleOpenDetails}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}

            {activeView === 'friends' && <FriendsView />}

            {activeView === 'saved' && (
              <SavedPostsView
                onOpenDetails={handleOpenDetails}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}

            {activeView === 'profile' && (
              <ProfileView
                onOpenChangePassword={() => handleOpenAuth('change-password')}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}

            {activeView === 'user-profile' && viewedUser && (
              <UserProfileView
                user={viewedUser}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}

            {activeView === 'post-details' && selectedPost && (
              <PostDetailsView
                post={selectedPost}
                onBack={() => setActiveView('feed')}
                onOpenImage={(url) => setLightboxImage(url)}
                onEditPost={handleEditPost}
              />
            )}
          </div>

          {/* Right Discovery Sidebar */}
          <RightSidebar />
        </div>
      </main>

      {/* 3. Modals & Overlays */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authModalMode}
        onClose={() => setAuthModalOpen(false)}
      />

      <CreatePostModal
        isOpen={createPostModalOpen}
        onClose={() => setCreatePostModalOpen(false)}
      />

      <EditPostModal
        post={editingPost}
        isOpen={!!editingPost}
        onClose={() => setEditingPost(null)}
      />

      <LightboxModal
        imageUrl={lightboxImage}
        onClose={() => setLightboxImage(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <PostProvider>
          <NotificationProvider>
            <AppContent />
          </NotificationProvider>
        </PostProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
