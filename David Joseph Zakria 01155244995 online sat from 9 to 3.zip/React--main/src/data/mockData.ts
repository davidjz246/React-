import { Post, User } from '../types';

export const CURRENT_USER: User = {
  _id: 'user_alexa_current',
  name: 'Alexa Chen',
  email: 'alexa.chen@designcraft.io',
  handle: '@alexachen',
  photo: '/src/assets/images/avatar_alexa_chen_1791362803647.jpg',
  gender: 'female',
  dateOfBirth: '1996-04-18',
  bio: 'Design Systems Architect & Creative Technologist. Building calm, humane digital spaces.',
  createdAt: '2024-01-15T10:00:00.000Z',
  followersCount: 1420,
  followingCount: 380,
};

export const INITIAL_POSTS: Post[] = [
  {
    _id: 'post_desk_02',
    body: 'Sunday morning workspace ritual: espresso, natural oak grain, silence, and 0 notification badges. Deep work requires spatial clarity before digital velocity.',
    image: '/src/assets/images/feed_nordic_workspace_1791362835082.jpg',
    user: {
      _id: 'user_alexa_current',
      name: 'Alexa Chen',
      email: 'alexa.chen@designcraft.io',
      handle: '@alexachen',
      photo: '/src/assets/images/avatar_alexa_chen_1791362803647.jpg',
    },
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    likesCount: 45,
    isLiked: false,
    isSaved: false,
    sharesCount: 12,
    tags: ['Workspace', 'DesignSystems'],
    aspectRatio: '4:3',
    comments: [],
  },
];
