import React, { useState } from 'react';
import { User, Post } from '../types';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { PostCard } from './PostCard';
import {
  UserPlus,
  UserCheck,
  UserX,
  Clock,
  ArrowLeft,
  Mail,
  Calendar,
  Layers,
  Grid,
  Share2,
} from 'lucide-react';

interface UserProfileViewProps {
  user: User;
  onOpenImage?: (url: string) => void;
  onEditPost?: (post: Post) => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  user,
  onOpenImage,
  onEditPost,
}) => {
  const {
    getFriendshipState,
    sendFriendRequest,
    cancelFriendRequest,
    removeFriend,
  } = useAuth();
  const { posts, setActiveView } = usePosts();
  const [activeTab, setActiveTab] = useState<'timeline' | 'shared' | 'media'>('timeline');

  const isPostAuthored = (p: Post) =>
    p.user?._id === user._id || p.user?.email === user.email || (p.user?.name && p.user.name === user.name);

  const isPostShared = (p: Post) =>
    !!p.sharedBy && p.sharedBy.includes(user._id);

  const userPosts = posts.filter((p) => isPostAuthored(p) || isPostShared(p));
  const userSharedPosts = posts.filter((p) => isPostShared(p) && !isPostAuthored(p));
  const mediaPosts = userPosts.filter((p) => !!p.image);
  const friendState = getFriendshipState(user._id);

  const getDisplayedPosts = () => {
    switch (activeTab) {
      case 'shared':
        return userSharedPosts;
      case 'media':
        return mediaPosts;
      default:
        return userPosts;
    }
  };

  const displayedPosts = getDisplayedPosts();

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Return Breadcrumb */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => setActiveView('feed')}
          className="inline-flex items-center gap-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-white shadow-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Feed</span>
        </button>

        <span className="text-xs text-slate-500 font-mono">
          {userPosts.length} Publications
        </span>
      </div>

      {/* User Header Profile Card */}
      <div className="overflow-hidden rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {/* Cover Banner */}
        <div className="h-32 bg-gradient-to-r from-indigo-900 via-violet-900 to-slate-900 relative">
          <div className="absolute inset-0 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px] opacity-25" />
        </div>

        {/* Profile Info Row */}
        <div className="relative px-6 pb-6 pt-0">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12 mb-4">
            {/* Avatar */}
            <div className="relative">
              {user.photo ? (
                <img
                  src={user.photo}
                  alt={user.name}
                  referrerPolicy="no-referrer"
                  className="h-24 w-24 rounded-2xl object-cover ring-4 ring-white dark:ring-slate-900 shadow-xl"
                />
              ) : (
                <div className="flex h-24 w-24 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-700 text-3xl font-bold text-white shadow-xl ring-4 ring-white dark:ring-slate-900">
                  {user.name?.charAt(0).toUpperCase() || 'U'}
                </div>
              )}
            </div>

            {/* Friend Request Action */}
            <div className="flex items-center gap-2.5">
              {friendState === 'friends' ? (
                <button
                  type="button"
                  onClick={() => removeFriend(user._id)}
                  className="flex items-center gap-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 px-4 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 transition-all cursor-pointer"
                  title="Click to unfriend"
                >
                  <UserCheck className="h-3.5 w-3.5" />
                  <span>Friends</span>
                </button>
              ) : friendState === 'pending_sent' ? (
                <button
                  type="button"
                  onClick={() => cancelFriendRequest(user._id)}
                  className="flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors cursor-pointer"
                >
                  <Clock className="h-3.5 w-3.5" />
                  <span>Cancel Request</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => sendFriendRequest(user._id)}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 shadow-xs transition-all cursor-pointer"
                >
                  <UserPlus className="h-3.5 w-3.5" />
                  <span>Add Friend</span>
                </button>
              )}
            </div>
          </div>

          {/* User Details */}
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 font-display">
                {user.name}
              </h1>
              <span className="text-xs text-indigo-500 font-mono">
                {user.handle || '@' + user.name.toLowerCase().replace(/\s+/g, '')}
              </span>
            </div>

            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              {user.bio || 'Creative contributor on Oasis.'}
            </p>

            {/* Unboxed Metadata */}
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
              {user.email && (
                <div className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-slate-400" />
                  <span>{user.email}</span>
                </div>
              )}
              <span aria-hidden="true" className="text-slate-400">·</span>
              <div className="flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5 text-slate-400" />
                <span>Active Member</span>
              </div>
            </div>

            {/* Stats */}
            <div className="mt-5 flex items-center gap-6 border-t border-slate-100 dark:border-slate-800/80 pt-4 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {userPosts.length}
                </span>
                <span className="text-slate-500">Posts</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {user.followersCount || 0}
                </span>
                <span className="text-slate-500">Followers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {user.followingCount || 0}
                </span>
                <span className="text-slate-500">Following</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('timeline')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'timeline'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Layers className="h-3.5 w-3.5" />
          <span>Timeline ({userPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('shared')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'shared'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Share2 className="h-3.5 w-3.5" />
          <span>Shared ({userSharedPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('media')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'media'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Grid className="h-3.5 w-3.5" />
          <span>Photos ({mediaPosts.length})</span>
        </button>
      </div>

      {/* Posts List */}
      <div className="space-y-4">
        {displayedPosts.length > 0 ? (
          displayedPosts.map((post) => (
            <PostCard
              key={post._id}
              post={post}
              onOpenImage={onOpenImage}
              onEditPost={onEditPost}
            />
          ))
        ) : (
          <div className="rounded-2xl bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 p-12 text-center">
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              No publications yet from {user.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Check back soon for new thoughts and project updates.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
