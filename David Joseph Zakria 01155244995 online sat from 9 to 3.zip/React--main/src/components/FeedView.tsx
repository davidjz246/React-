import React from 'react';
import { usePosts } from '../context/PostContext';
import { CreatePostBox } from './CreatePostBox';
import { PostCard } from './PostCard';
import { Post } from '../types';
import { RefreshCw, Sparkles } from 'lucide-react';

interface FeedViewProps {
  onOpenDetails: (post: Post) => void;
  onOpenImage: (url: string) => void;
  onEditPost: (post: Post) => void;
}

export const FeedView: React.FC<FeedViewProps> = ({
  onOpenDetails,
  onOpenImage,
  onEditPost,
}) => {
  const {
    feedPosts,
    isLoading,
    isRefreshing,
    loadPosts,
    searchQuery,
  } = usePosts();

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* 1. Quick Post Creation Box */}
      <CreatePostBox />

      {/* 2. Top Header & Refresh Bar */}
      <div className="flex items-center justify-between gap-3 px-1">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">
            Latest Publications
          </h2>
        </div>

        {/* Refresh Feed Button */}
        <button
          type="button"
          onClick={() => loadPosts(false)}
          disabled={isRefreshing}
          className="flex items-center gap-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 shadow-xs transition-colors cursor-pointer"
          title="Refresh stream"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? 'animate-spin text-indigo-500' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Active Search Notification */}
      {searchQuery.trim() && (
        <div className="text-xs text-slate-500 dark:text-slate-400 px-1">
          Showing search results for: <strong className="text-indigo-600 dark:text-indigo-300 font-mono">"{searchQuery}"</strong> ({feedPosts.length} publications found)
        </div>
      )}

      {/* 3. Stream Loading Skeletons */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2].map((n) => (
            <div
              key={n}
              className="animate-pulse rounded-2xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80 p-5 space-y-4"
            >
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-slate-200 dark:bg-slate-800" />
                <div className="space-y-2 flex-1">
                  <div className="h-3 w-32 rounded bg-slate-200 dark:bg-slate-800" />
                  <div className="h-2.5 w-20 rounded bg-slate-200 dark:bg-slate-800/70" />
                </div>
              </div>
              <div className="h-4 w-full rounded bg-slate-200 dark:bg-slate-800/70" />
              <div className="h-4 w-3/4 rounded bg-slate-200 dark:bg-slate-800/70" />
              <div className="h-48 w-full rounded-xl bg-slate-200 dark:bg-slate-800/50" />
            </div>
          ))}
        </div>
      ) : feedPosts.length > 0 ? (
        /* 4. Populated Post Cards Stream */
        <div className="space-y-4">
          {feedPosts.map((post: Post) => (
            <PostCard
              key={post._id}
              post={post}
              onOpenDetails={onOpenDetails}
              onOpenImage={onOpenImage}
              onEditPost={onEditPost}
            />
          ))}
        </div>
      ) : (
        /* 5. Empty State */
        <div className="rounded-2xl bg-white dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800/80 p-12 text-center space-y-3">
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            No posts found in the community feed
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {searchQuery
              ? 'Try changing your search keywords.'
              : 'Be the first to publish a thought or upload a photo using the composer above!'}
          </p>
        </div>
      )}
    </div>
  );
};
