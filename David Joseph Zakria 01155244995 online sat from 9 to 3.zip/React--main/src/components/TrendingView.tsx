import React from 'react';
import { usePosts } from '../context/PostContext';
import { PostCard } from './PostCard';
import { Post } from '../types';
import { Flame, TrendingUp, Sparkles, MessageCircle, ArrowLeft } from 'lucide-react';

interface TrendingViewProps {
  onOpenDetails: (post: Post) => void;
  onOpenImage: (url: string) => void;
  onEditPost: (post: Post) => void;
}

export const TrendingView: React.FC<TrendingViewProps> = ({
  onOpenDetails,
  onOpenImage,
  onEditPost,
}) => {
  const { trendingPosts, setActiveView, searchQuery } = usePosts();

  const trendingTopics = [
    { tag: 'Architecture', count: '3.4k discussions', change: '+24%' },
    { tag: 'DesignSystems', count: '2.1k discussions', change: '+18%' },
    { tag: 'Philosophy', count: '1.8k discussions', change: '+12%' },
    { tag: 'Minimalism', count: '1.2k discussions', change: '+9%' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Trending Header Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-amber-500/10 via-white dark:via-slate-900 to-white dark:to-slate-900 border border-amber-500/20 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-500 text-white shadow-md shadow-amber-500/30">
              <Flame className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                Trending Discussions
              </h1>
              <p className="text-xs text-slate-500">
                Most engaging publications ranked by community replies and discussion velocity
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveView('feed')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline shrink-0 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Discover Feed</span>
          </button>
        </div>

        {/* Hot Topics Carousel */}
        <div className="mt-5 pt-4.5 border-t border-slate-100 dark:border-slate-800/80">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-2.5 px-0.5">
            Hot Community Topics
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            {trendingTopics.map((topic) => (
              <div
                key={topic.tag}
                className="p-3.5 rounded-xl bg-white/70 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 hover:border-amber-400/50 hover:shadow-xs transition-all"
              >
                <p className="font-bold text-slate-900 dark:text-slate-100 text-sm">{topic.tag}</p>
                <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
                  <span>{topic.count}</span>
                  <span className="text-emerald-500 font-semibold">{topic.change}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stream */}
      {trendingPosts.length > 0 ? (
        <div className="space-y-4">
          {trendingPosts.map((post, idx) => (
            <div key={post._id} className="relative">
              {/* Leaderboard Rank Tag */}
              <div className="absolute -left-3 top-3 z-10 hidden xl:flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-[11px] font-bold text-white shadow-md">
                #{idx + 1}
              </div>
              <PostCard
                post={post}
                onOpenDetails={onOpenDetails}
                onOpenImage={onOpenImage}
                onEditPost={onEditPost}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 p-12 text-center space-y-3">
          <Flame className="mx-auto h-8 w-8 text-amber-500" />
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            No trending posts yet
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Interact with posts in the discover feed by liking and commenting to elevate them to the trending leaderboard!
          </p>
        </div>
      )}
    </div>
  );
};
