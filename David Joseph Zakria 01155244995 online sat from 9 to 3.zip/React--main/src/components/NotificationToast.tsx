import React from 'react';
import { useNotifications } from '../context/NotificationContext';
import { usePosts } from '../context/PostContext';
import { Heart, MessageCircle, UserPlus, UserCheck, X, Sparkles, Share2 } from 'lucide-react';

export const NotificationToast: React.FC = () => {
  const { toastNotification, dismissToast, markAsRead } = useNotifications();
  const { setActiveView, setSelectedPost, posts } = usePosts();

  if (!toastNotification) return null;

  const handleClick = () => {
    markAsRead(toastNotification.id);
    if (toastNotification.type === 'friend_request' || toastNotification.type === 'friend_accept') {
      setActiveView('friends');
    } else if (toastNotification.type === 'like' || toastNotification.type === 'comment' || toastNotification.type === 'share') {
      if (toastNotification.targetId) {
        const found = posts.find((p) => p._id === toastNotification.targetId);
        if (found) {
          setSelectedPost(found);
          setActiveView('post-details');
        } else {
          setActiveView('feed');
        }
      } else {
        setActiveView('feed');
      }
    }
    dismissToast();
  };

  const getIcon = () => {
    switch (toastNotification.type) {
      case 'like':
        return (
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-rose-500 text-white shadow-md shadow-rose-500/30">
            <Heart className="h-3.5 w-3.5 fill-white" />
          </div>
        );
      case 'comment':
        return (
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-cyan-500 text-white shadow-md shadow-cyan-500/30">
            <MessageCircle className="h-3.5 w-3.5" />
          </div>
        );
      case 'share':
        return (
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-500 text-white shadow-md shadow-emerald-500/30">
            <Share2 className="h-3.5 w-3.5" />
          </div>
        );
      case 'friend_request':
        return (
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
            <UserPlus className="h-3.5 w-3.5" />
          </div>
        );
      case 'friend_accept':
        return (
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-500 text-white shadow-md shadow-emerald-500/30">
            <UserCheck className="h-3.5 w-3.5" />
          </div>
        );
      default:
        return (
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-500 text-white">
            <Sparkles className="h-3.5 w-3.5" />
          </div>
        );
    }
  };

  return (
    <div className="fixed top-20 right-4 sm:right-8 z-50 max-w-sm w-full animate-in slide-in-from-top-4 fade-in duration-300">
      <div
        onClick={handleClick}
        className="flex items-start gap-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 p-3.5 shadow-2xl backdrop-blur-md cursor-pointer hover:border-indigo-500/50 transition-all group"
      >
        {getIcon()}

        <div className="min-w-0 flex-1 space-y-0.5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
              {toastNotification.title}
            </p>
            <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider font-mono">
              Just Now
            </span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-snug">
            {toastNotification.message}
          </p>
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            dismissToast();
          }}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
};
