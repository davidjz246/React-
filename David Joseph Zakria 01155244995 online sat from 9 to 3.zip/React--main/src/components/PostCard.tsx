import React, { useState, useRef } from 'react';
import { Post, User } from '../types';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { CommentItem } from './CommentItem';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  Edit3,
  Trash2,
  Copy,
  Send,
  Maximize2,
  Check,
  UserPlus,
  UserCheck,
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  onOpenDetails?: (post: Post) => void;
  onOpenImage?: (imageUrl: string) => void;
  onEditPost?: (post: Post) => void;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  onOpenDetails,
  onOpenImage,
  onEditPost,
}) => {
  const { user, networkUsers, getFriendshipState, sendFriendRequest, removeFriend } = useAuth();
  const {
    toggleLikePost,
    toggleSavePost,
    deletePost,
    sharePost,
    addComment,
    setActiveView,
    setSelectedPost,
    openUserProfile,
  } = usePosts();

  const [showComments, setShowComments] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const commentInputRef = useRef<HTMLInputElement>(null);

  const handleShare = async () => {
    await sharePost(post);
    navigator.clipboard?.writeText(window.location.href);
    setShared(true);
    setTimeout(() => setShared(false), 2500);
    setShowMenu(false);
  };

  // Check if current user is author
  const isAuthor =
    user && (user._id === post.user?._id || user.email === post.user?.email || (user.name && user.name === post.user?.name));

  const friendState = post.user?._id ? getFriendshipState(post.user._id) : 'none';

  const formatTime = (isoString?: string) => {
    if (!isoString) return 'Just now';
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const mins = Math.floor(diff / (1000 * 60));
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / (1000 * 60 * 60));
      if (hours < 24) return `${hours}h ago`;
      const days = Math.floor(hours / 24);
      if (days < 7) return `${days}d ago`;
      return new Date(isoString).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return 'Recent';
    }
  };

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || isSubmittingComment) return;

    setIsSubmittingComment(true);
    try {
      await addComment(post._id, commentInput.trim());
      setCommentInput('');
      setShowComments(true);
      setTimeout(() => {
        commentInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 100);
    } catch (err) {
      console.error('Failed to post comment:', err);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    setShowMenu(false);
  };

  const handleDeletePost = async () => {
    if (confirm('Are you sure you want to delete this publication?')) {
      await deletePost(post._id);
    }
    setShowMenu(false);
  };

  const openDetailsView = () => {
    if (onOpenDetails) {
      onOpenDetails(post);
    } else {
      setSelectedPost(post);
      setActiveView('post-details');
    }
  };

  const handleAuthorClick = () => {
    if (post.user) {
      const existing = networkUsers.find((u) => u._id === post.user._id);
      const userObj: User = existing || {
        _id: post.user._id,
        name: post.user.name,
        email: post.user.email || '',
        photo: post.user.photo,
        handle: post.user.handle,
        followersCount: 0,
        followingCount: 0,
      };
      openUserProfile(userObj);
    }
  };

  const isLongText = post.body && post.body.length > 280;
  const displayedText =
    isLongText && !isExpanded ? `${post.body.slice(0, 280)}...` : post.body;

  const getAspectRatioClass = (ratio?: string) => {
    switch (ratio) {
      case '16:9':
        return 'aspect-[16/9]';
      case '4:3':
        return 'aspect-[4/3]';
      case '1:1':
        return 'aspect-square';
      case '9:16':
        return 'aspect-[9/16] max-h-[500px] object-cover';
      default:
        return 'max-h-[520px] object-cover';
    }
  };

  return (
    <article className="group relative rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800/80 p-5 shadow-xs transition-all hover:border-slate-300 dark:hover:border-slate-700/80 hover:shadow-sm">
      {/* 1. Header: Author and Metadata */}
      <div className="flex items-start justify-between gap-3 mb-3.5">
        <div className="flex items-center gap-3">
          {/* Avatar Clickable to View Profile */}
          <div
            onClick={handleAuthorClick}
            className="relative cursor-pointer transition-transform hover:scale-105"
            title={`View ${post.user?.name || 'User'}'s profile`}
          >
            {post.user?.photo ? (
              <img
                src={post.user.photo}
                alt={post.user.name || 'Author'}
                referrerPolicy="no-referrer"
                className="h-10 w-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-600 to-violet-700 text-sm font-bold text-white shadow-inner">
                {post.user?.name?.charAt(0).toUpperCase() || 'A'}
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span
                onClick={handleAuthorClick}
                className="font-semibold text-slate-900 dark:text-slate-100 text-sm hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors cursor-pointer"
              >
                {post.user?.name || 'Anonymous Creator'}
              </span>
              {post.user?.handle && (
                <span className="text-xs text-slate-400 hidden sm:inline">
                  {post.user.handle}
                </span>
              )}
            </div>

            {/* Zero-Pill Unboxed Metadata */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <time className="tabular-nums">{formatTime(post.createdAt)}</time>
              {post.tags && post.tags.length > 0 && post.tags[0] && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-indigo-600 dark:text-indigo-400 font-medium truncate max-w-[150px]">
                    {post.tags[0].replace(/^#+/, '')}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Dropdown Menu & Quick Action */}
        <div className="flex items-center gap-1 relative">
          {/* Quick Friend request toggle if not current user */}
          {!isAuthor && post.user?._id && (
            <button
              type="button"
              onClick={() => {
                if (friendState === 'friends') {
                  removeFriend(post.user._id);
                } else if (friendState === 'none') {
                  sendFriendRequest(post.user._id);
                }
              }}
              className={`hidden sm:flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold transition-colors cursor-pointer ${
                friendState === 'friends'
                  ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30'
                  : friendState === 'pending_sent'
                  ? 'text-slate-400 bg-slate-100 dark:bg-slate-800'
                  : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40'
              }`}
            >
              {friendState === 'friends' ? <UserCheck className="h-3 w-3" /> : <UserPlus className="h-3 w-3" />}
              <span>
                {friendState === 'friends'
                  ? 'Friends'
                  : friendState === 'pending_sent'
                  ? 'Pending'
                  : 'Add Friend'}
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setShowMenu(!showMenu)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-pointer"
            title="More options"
          >
            <MoreHorizontal className="h-4 w-4" />
          </button>

          {showMenu && (
            <div className="absolute right-0 top-8 z-30 w-44 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/90 py-1.5 shadow-2xl backdrop-blur-md">
              <button
                type="button"
                onClick={handleCopyLink}
                className="flex w-full items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? 'Link Copied!' : 'Copy Link'}
              </button>

              <button
                type="button"
                onClick={() => {
                  toggleSavePost(post._id);
                  setShowMenu(false);
                }}
                className="flex w-full items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Bookmark className={`h-3.5 w-3.5 ${post.isSaved ? 'fill-amber-500 text-amber-500' : ''}`} />
                {post.isSaved ? 'Remove from Saved' : 'Save Post'}
              </button>

              <button
                type="button"
                onClick={() => {
                  handleAuthorClick();
                  setShowMenu(false);
                }}
                className="flex w-full items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <span className="h-3.5 w-3.5 font-bold">@</span>
                <span>View Author Profile</span>
              </button>

              {isAuthor && (
                <>
                  <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                  <button
                    type="button"
                    onClick={() => {
                      setShowMenu(false);
                      if (onEditPost) onEditPost(post);
                    }}
                    className="flex w-full items-center gap-2.5 px-3.5 py-2 text-xs text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 cursor-pointer"
                  >
                    <Edit3 className="h-3.5 w-3.5" /> Edit Post
                  </button>
                  {showDeleteConfirm ? (
                    <div className="p-2.5 m-1.5 space-y-2 bg-rose-50 dark:bg-rose-950/60 rounded-xl border border-rose-200 dark:border-rose-900">
                      <p className="text-[11px] font-semibold text-rose-700 dark:text-rose-300 text-center">
                        Permanently delete?
                      </p>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            await deletePost(post._id);
                            setShowMenu(false);
                          }}
                          className="flex-1 rounded-lg bg-rose-600 py-1.5 text-xs font-semibold text-white hover:bg-rose-500 cursor-pointer shadow-xs"
                        >
                          Yes, Delete
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowDeleteConfirm(false)}
                          className="flex-1 rounded-lg bg-slate-200 dark:bg-slate-700 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowDeleteConfirm(true)}
                      className="flex w-full items-center gap-2.5 px-3.5 py-2 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete Post
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 2. Body Text */}
      {post.body && (
        <div className="mb-3.5">
          <p className="text-sm leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-line break-words">
            {displayedText}
          </p>
          {isLongText && (
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="mt-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              {isExpanded ? 'Show less' : 'Show more'}
            </button>
          )}
        </div>
      )}

      {/* 3. Media Image Slot */}
      {post.image && (
        <div className="relative mb-4 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/60 group/media">
          <img
            src={post.image}
            alt="Post media"
            referrerPolicy="no-referrer"
            className={`w-full object-cover transition-transform duration-300 group-hover/media:scale-[1.01] ${getAspectRatioClass(
              post.aspectRatio
            )}`}
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />

          <button
            type="button"
            onClick={() => onOpenImage && onOpenImage(post.image!)}
            className="absolute bottom-3 right-3 rounded-lg bg-slate-950/80 p-2 text-slate-300 opacity-0 backdrop-blur-md transition-opacity group-hover/media:opacity-100 hover:text-white cursor-pointer"
            title="Expand photo"
          >
            <Maximize2 className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* 4. Action Row */}
      <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800/80 pt-3 text-xs text-slate-500 dark:text-slate-400">
        <button
          type="button"
          onClick={() => toggleLikePost(post._id)}
          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 transition-colors cursor-pointer ${
            post.isLiked
              ? 'text-rose-600 dark:text-rose-400 font-semibold bg-rose-50 dark:bg-rose-950/30'
              : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Heart
            className={`h-4 w-4 transition-transform active:scale-125 ${
              post.isLiked ? 'fill-rose-500 text-rose-500' : ''
            }`}
          />
          <span className="tabular-nums font-mono">
            {post.likesCount || 0}
          </span>
          <span className="hidden sm:inline">Likes</span>
        </button>

        <button
          type="button"
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-pointer"
        >
          <MessageCircle className="h-4 w-4" />
          <span className="tabular-nums font-mono">
            {post.comments?.length || 0}
          </span>
          <span className="hidden sm:inline">Comments</span>
        </button>

        <button
          type="button"
          onClick={handleShare}
          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 transition-colors cursor-pointer ${
            shared
              ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 font-semibold'
              : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
          title="Share post to your profile"
        >
          <Share2 className="h-4 w-4" />
          <span className="tabular-nums font-mono">
            {post.sharesCount || 0}
          </span>
          <span className="hidden sm:inline">{shared ? 'Shared!' : 'Share'}</span>
        </button>

        <button
          type="button"
          onClick={() => toggleSavePost(post._id)}
          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 transition-colors cursor-pointer ${
            post.isSaved
              ? 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 font-semibold'
              : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
          title="Save post"
        >
          <Bookmark
            className={`h-4 w-4 ${
              post.isSaved ? 'fill-amber-500 text-amber-500' : ''
            }`}
          />
          <span className="hidden sm:inline">
            {post.isSaved ? 'Saved' : 'Save'}
          </span>
        </button>
      </div>

      {/* 5. Comments Section */}
      {showComments && (
        <div className="mt-4 border-t border-slate-100 dark:border-slate-800/80 pt-3.5 space-y-3">
          <form onSubmit={handleCommentSubmit} className="flex gap-2.5">
            <div className="relative shrink-0">
              {user?.photo ? (
                <img
                  src={user.photo}
                  alt={user.name}
                  referrerPolicy="no-referrer"
                  className="h-7 w-7 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-800"
                />
              ) : (
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                  {user?.name?.charAt(0) || 'U'}
                </div>
              )}
            </div>

            <div className="relative flex-1">
              <input
                ref={commentInputRef}
                type="text"
                placeholder="Write a comment..."
                value={commentInput}
                onChange={(e) => {
                  setCommentInput(e.target.value);
                  commentInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }}
                className="w-full rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-1.5 pr-10 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:border-indigo-500 focus:outline-none transition-colors"
              />
              <button
                type="submit"
                disabled={!commentInput.trim() || isSubmittingComment}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-lg p-1 text-indigo-600 dark:text-indigo-400 hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-40 cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
          </form>

          <div className="space-y-1 divide-y divide-slate-100 dark:divide-slate-800/40">
            {post.comments && post.comments.length > 0 ? (
              post.comments.slice(0, 3).map((comm) => (
                <CommentItem key={comm._id} comment={comm} postId={post._id} />
              ))
            ) : (
              <p className="py-2 text-center text-xs text-slate-500">
                No comments yet. Be the first to reply!
              </p>
            )}
          </div>

          {post.comments && post.comments.length > 3 && (
            <button
              type="button"
              onClick={openDetailsView}
              className="w-full py-1.5 text-center text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              View all {post.comments.length} comments &rarr;
            </button>
          )}
        </div>
      )}
    </article>
  );
};
