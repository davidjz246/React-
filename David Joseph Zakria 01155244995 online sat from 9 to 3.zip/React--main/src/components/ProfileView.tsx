import React, { useState, useRef } from 'react';
import { User, Post } from '../types';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { PostCard } from './PostCard';
import {
  Camera,
  Trash2,
  KeyRound,
  Calendar,
  Mail,
  Grid,
  Heart,
  Bookmark,
  Layers,
  LogOut,
  ArrowLeft,
  Check,
  Share2,
} from 'lucide-react';

interface ProfileViewProps {
  onOpenChangePassword: () => void;
  onOpenImage?: (url: string) => void;
  onEditPost?: (post: Post) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onOpenChangePassword,
  onOpenImage,
  onEditPost,
}) => {
  const { user, updateProfilePhoto, removeProfilePhoto, logout, friends } = useAuth();
  const { posts, setActiveView } = usePosts();
  const [activeTab, setActiveTab] = useState<'posts' | 'shared' | 'media' | 'liked' | 'saved'>('posts');
  const [isUploading, setIsUploading] = useState(false);
  const [photoFeedback, setPhotoFeedback] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isPostAuthoredByMe = (p: Post) =>
    user && (p.user?._id === user._id || p.user?.email === user.email || (user.name && p.user?.name === user.name));

  const isPostSharedByMe = (p: Post) =>
    user && (p.isShared || (p.sharedBy && p.sharedBy.includes(user._id)));

  // All publications on profile: authored + shared to profile
  const myPosts = posts.filter((p) => isPostAuthoredByMe(p) || isPostSharedByMe(p));
  const mySharedPosts = posts.filter((p) => isPostSharedByMe(p) && !isPostAuthoredByMe(p));
  const myMediaPosts = myPosts.filter((p) => !!p.image);
  const myLikedPosts = posts.filter((p) => p.isLiked);
  const mySavedPosts = posts.filter((p) => p.isSaved);

  const getDisplayedPosts = () => {
    switch (activeTab) {
      case 'shared':
        return mySharedPosts;
      case 'media':
        return myMediaPosts;
      case 'liked':
        return myLikedPosts;
      case 'saved':
        return mySavedPosts;
      default:
        return myPosts;
    }
  };

  const displayed = getDisplayedPosts();

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsUploading(true);
      try {
        await updateProfilePhoto(e.target.files[0]);
        setPhotoFeedback('Profile photo updated!');
        setTimeout(() => setPhotoFeedback(null), 2500);
      } catch (err) {
        console.error('Failed to upload photo:', err);
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleRemovePhoto = () => {
    removeProfilePhoto();
    setPhotoFeedback('Profile photo removed!');
    setTimeout(() => setPhotoFeedback(null), 2500);
  };

  const formattedJoinDate = user?.createdAt
    ? new Date(user.createdAt).toLocaleDateString('en-US', {
        month: 'long',
        year: 'numeric',
      })
    : 'October 2026';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Back to Feed Button */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => setActiveView('feed')}
          className="inline-flex items-center gap-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-white shadow-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Feed</span>
        </button>

        <span className="text-xs text-slate-500 font-mono">
          {myPosts.length} Publications
        </span>
      </div>

      {/* Profile Header Banner & Card */}
      <div className="overflow-hidden rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {/* Cover Banner */}
        <div className="h-36 bg-gradient-to-r from-indigo-900 via-slate-900 to-violet-950 relative">
          <div className="absolute inset-0 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px] opacity-25" />
        </div>

        {/* Profile Info Row */}
        <div className="relative px-6 pb-6 pt-0">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-14 mb-4">
            {/* Avatar with Upload & Remove Actions */}
            <div className="flex items-end gap-3">
              <div className="relative group">
                {user?.photo ? (
                  <img
                    src={user.photo}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="h-24 w-24 rounded-2xl object-cover ring-4 ring-white dark:ring-slate-900 shadow-xl"
                  />
                ) : (
                  <div className="flex h-24 w-24 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-700 text-3xl font-bold text-white shadow-xl ring-4 ring-white dark:ring-slate-900">
                    {user?.name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}

                {/* Upload Overlay */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="absolute inset-0 flex items-center justify-center rounded-2xl bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity text-white backdrop-blur-xs cursor-pointer"
                  title="Upload profile picture"
                >
                  <Camera className="h-6 w-6" />
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePhotoUpload}
                  accept="image/*"
                  className="hidden"
                />
              </div>

              {/* Action buttons for photo */}
              <div className="flex flex-col gap-1 text-xs">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer"
                >
                  <Camera className="h-3.5 w-3.5" />
                  <span>{user?.photo ? 'Change Photo' : 'Upload Photo'}</span>
                </button>
                {user?.photo && (
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    className="flex items-center gap-1 text-rose-500 hover:text-rose-600 font-medium hover:underline cursor-pointer text-xs"
                  >
                    <Trash2 className="h-3 w-3" />
                    <span>Remove Photo</span>
                  </button>
                )}
                {photoFeedback && (
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1 animate-in fade-in">
                    <Check className="h-3 w-3" /> {photoFeedback}
                  </span>
                )}
              </div>
            </div>

            {/* Actions: Change Password & Sign Out */}
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onOpenChangePassword}
                className="flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-white transition-colors cursor-pointer"
              >
                <KeyRound className="h-3.5 w-3.5 text-indigo-500" />
                <span>Change Password</span>
              </button>

              <button
                type="button"
                onClick={logout}
                className="flex items-center gap-2 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/50 transition-colors cursor-pointer"
                title="Log out and return to sign in"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          </div>

          {/* User Details */}
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 font-display">
                {user?.name || 'My Profile'}
              </h1>
              <span className="text-xs text-indigo-600 dark:text-indigo-400 font-mono">
                {user?.handle || '@member'}
              </span>
            </div>

            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              {user?.bio || 'Building clean, intentional publications on Oasis.'}
            </p>

            {/* Unboxed Meta */}
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-slate-400" />
                <span>{user?.email}</span>
              </div>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-600">·</span>
              <div className="flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5 text-slate-400" />
                <span>Joined {formattedJoinDate}</span>
              </div>
            </div>

            {/* Realistic Follower & Following Stats */}
            <div className="mt-5 flex flex-wrap items-center gap-4 sm:gap-6 border-t border-slate-100 dark:border-slate-800/80 pt-4 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {myPosts.length}
                </span>
                <span className="text-slate-500">My Posts</span>
              </div>
              <div
                onClick={() => setActiveView('friends')}
                className="flex items-center gap-1.5 cursor-pointer hover:text-indigo-600"
              >
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {friends.length}
                </span>
                <span className="text-slate-500">Friends</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {user?.followersCount || 0}
                </span>
                <span className="text-slate-500">Followers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums font-mono">
                  {user?.followingCount || 0}
                </span>
                <span className="text-slate-500">Following</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 rounded-xl shadow-xs overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('posts')}
          className={`flex-1 min-w-[85px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'posts'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Layers className="h-3.5 w-3.5" />
          <span>All ({myPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('shared')}
          className={`flex-1 min-w-[85px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'shared'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Share2 className="h-3.5 w-3.5" />
          <span>Shared ({mySharedPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('media')}
          className={`flex-1 min-w-[85px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'media'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Grid className="h-3.5 w-3.5" />
          <span>Photos ({myMediaPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('liked')}
          className={`flex-1 min-w-[85px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'liked'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Heart className="h-3.5 w-3.5" />
          <span>Liked ({myLikedPosts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('saved')}
          className={`flex-1 min-w-[85px] flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeTab === 'saved'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Bookmark className="h-3.5 w-3.5" />
          <span>Saved ({mySavedPosts.length})</span>
        </button>
      </div>

      {/* Posts */}
      <div className="space-y-4">
        {displayed.length > 0 ? (
          displayed.map((post) => (
            <PostCard
              key={post._id}
              post={post}
              onOpenImage={onOpenImage}
              onEditPost={onEditPost}
            />
          ))
        ) : (
          <div className="rounded-2xl bg-white dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800/80 p-12 text-center">
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-300">
              No publications in this tab
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Create a new post in the feed or save publications to see them here!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
