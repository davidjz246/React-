import React, { useState } from 'react';
import { Post } from '../types';
import { usePosts } from '../context/PostContext';
import { X, Image as ImageIcon, Check } from 'lucide-react';

interface EditPostModalProps {
  post: Post | null;
  isOpen: boolean;
  onClose: () => void;
}

export const EditPostModal: React.FC<EditPostModalProps> = ({ post, isOpen, onClose }) => {
  if (!isOpen || !post) return null;

  const { updatePost } = usePosts();
  const [bodyText, setBodyText] = useState(post.body || '');
  const [topic, setTopic] = useState(post.tags && post.tags.length > 0 ? post.tags[0] : '');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(post.image || null);
  const [isSaving, setIsSaving] = useState(false);

  const suggestedTopics = ['Design', 'Architecture', 'Engineering', 'Systems', 'Philosophy', 'Technology', 'Art', 'Science', 'Culture'];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bodyText.trim() && !previewImage) return;

    setIsSaving(true);
    try {
      await updatePost(post._id, bodyText.trim(), selectedImage, topic || null);
      onClose();
    } catch (err) {
      console.error('Failed to update post:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
          <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100 font-display">
            Edit Publication
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Edit Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              Post Content
            </label>
            <textarea
              rows={4}
              value={bodyText}
              onChange={(e) => setBodyText(e.target.value)}
              className="w-full rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:border-indigo-500 focus:outline-none"
              placeholder="What do you want to share?"
            />
          </div>

          {/* Current / New Image Preview */}
          {previewImage && (
            <div className="relative overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
              <img
                src={previewImage}
                alt="Post attachment"
                className="w-full max-h-48 object-cover"
              />
              <button
                type="button"
                onClick={() => {
                  setSelectedImage(null);
                  setPreviewImage(null);
                }}
                className="absolute right-2.5 top-2.5 rounded-full bg-slate-950/80 p-1.5 text-white backdrop-blur hover:bg-slate-900 cursor-pointer"
                title="Remove photo"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* Topic selector */}
          <div className="rounded-xl bg-slate-50/80 dark:bg-slate-950/50 border border-slate-200/80 dark:border-slate-800 p-3.5 space-y-2.5 my-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5">
                <span>Topic</span>
                <span className="text-[11px] font-normal text-slate-400">
                  {topic ? `(${topic})` : '(Optional)'}
                </span>
              </span>
              {topic && (
                <button
                  type="button"
                  onClick={() => setTopic('')}
                  className="text-xs font-medium text-rose-500 hover:text-rose-600 hover:underline cursor-pointer"
                >
                  Clear topic
                </button>
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {suggestedTopics.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTopic(topic === t ? '' : t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    topic === t
                      ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                      : 'bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-1.5 cursor-pointer rounded-lg px-2.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
              <ImageIcon className="h-4 w-4 text-indigo-500" />
              <span>{previewImage ? 'Replace Photo' : 'Add Photo'}</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50 cursor-pointer"
              >
                <Check className="h-3.5 w-3.5" />
                <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
