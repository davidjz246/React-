import React from 'react';
import { usePosts } from '../context/PostContext';
import { PostCard } from './PostCard';
import { Post } from '../types';
import { Bookmark, ArrowLeft } from 'lucide-react';

interface SavedPostsViewProps {
  onOpenDetails: (post: Post) => void;
  onOpenImage: (url: string) => void;
  onEditPost: (post: Post) => void;
}

export const SavedPostsView: React.FC<SavedPostsViewProps> = ({
  onOpenDetails,
  onOpenImage,
  onEditPost,
}) => {
  const { posts, setActiveView } = usePosts();
  const savedPosts = posts.filter((p) => p.isSaved);

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 text-amber-500">
            <Bookmark className="h-5 w-5 fill-amber-500" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">
              Saved Publications
            </h1>
            <p className="text-xs text-slate-500">
              Personal archive of saved discussions and inspiration
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setActiveView('feed')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Feed</span>
        </button>
      </div>

      {/* Stream */}
      {savedPosts.length > 0 ? (
        <div className="space-y-4">
          {savedPosts.map((post) => (
            <PostCard
              key={post._id}
              post={post}
              onOpenDetails={onOpenDetails}
              onOpenImage={onOpenImage}
              onEditPost={onEditPost}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800/80 p-12 text-center space-y-3">
          <Bookmark className="mx-auto h-8 w-8 text-slate-400" />
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            No saved posts yet
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Click the bookmark icon on any post in your feed to save it here for later reference.
          </p>
          <button
            type="button"
            onClick={() => setActiveView('feed')}
            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Return to Feed</span>
          </button>
        </div>
      )}
    </div>
  );
};
