import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { Users, UserPlus, UserCheck, UserX, Clock, ArrowLeft } from 'lucide-react';

export const FriendsView: React.FC = () => {
  const {
    user,
    networkUsers,
    friends,
    receivedRequests,
    sentRequests,
    sendFriendRequest,
    cancelFriendRequest,
    acceptFriendRequest,
    removeFriend,
    getFriendshipState,
  } = useAuth();
  const { openUserProfile, setActiveView } = usePosts();

  const [activeTab, setActiveTab] = useState<'network' | 'requests' | 'friends'>('network');

  const otherUsers = networkUsers.filter((u) => u._id !== user?._id);
  const myFriendsList = otherUsers.filter((u) => friends.includes(u._id));

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
            <Users className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white font-display">
              Friends & Network Directory
            </h1>
            <p className="text-xs text-slate-500">
              Discover members across the Oasis network, manage friend requests, and grow your connections
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setActiveView('feed')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer self-start sm:self-auto"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Feed</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('network')}
          className={`flex-1 py-2.5 rounded-lg transition-all cursor-pointer ${
            activeTab === 'network'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          Explore Network ({otherUsers.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('requests')}
          className={`flex-1 py-2.5 rounded-lg transition-all relative cursor-pointer ${
            activeTab === 'requests'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <span>Friend Requests</span>
          {receivedRequests.length > 0 && (
            <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-rose-500 text-[10px] font-bold text-white">
              {receivedRequests.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('friends')}
          className={`flex-1 py-2.5 rounded-lg transition-all cursor-pointer ${
            activeTab === 'friends'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          My Friends ({myFriendsList.length})
        </button>
      </div>

      {/* Tab 1: Explore Network */}
      {activeTab === 'network' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {otherUsers.map((member) => {
              const status = getFriendshipState(member._id);
              return (
                <div
                  key={member._id}
                  className="flex flex-col justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                >
                  <div
                    onClick={() => openUserProfile(member)}
                    className="flex items-start gap-3 cursor-pointer group"
                  >
                    {member.photo ? (
                      <img
                        src={member.photo}
                        alt={member.name}
                        className="h-12 w-12 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800 shrink-0"
                      />
                    ) : (
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-600 to-violet-700 text-base font-bold text-white shrink-0 shadow-inner">
                        {member.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate transition-colors">
                        {member.name}
                      </p>
                      <p className="text-xs text-slate-400 truncate">{member.handle || '@member'}</p>
                      <p className="text-xs text-slate-500 line-clamp-1 mt-1">{member.bio || 'Aura creator'}</p>
                    </div>
                  </div>

                  {/* Followers & Follow button */}
                  <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800/80 pt-3 text-xs">
                    <div className="flex items-center gap-3 text-slate-500 font-mono text-[11px]">
                      <span>{member.followersCount || 0} Followers</span>
                      <span>·</span>
                      <span>{member.followingCount || 0} Following</span>
                    </div>

                    {status === 'friends' ? (
                      <button
                        type="button"
                        onClick={() => removeFriend(member._id)}
                        className="flex items-center gap-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 transition-colors cursor-pointer"
                        title="Click to remove friend"
                      >
                        <UserCheck className="h-3.5 w-3.5" />
                        <span>Friends</span>
                      </button>
                    ) : status === 'pending_sent' ? (
                      <button
                        type="button"
                        onClick={() => cancelFriendRequest(member._id)}
                        className="flex items-center gap-1 rounded-xl bg-slate-100 dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors cursor-pointer"
                        title="Cancel friend request"
                      >
                        <Clock className="h-3.5 w-3.5" />
                        <span>Request Sent</span>
                      </button>
                    ) : status === 'pending_received' ? (
                      <span className="text-xs font-bold text-indigo-600">Request Pending</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => sendFriendRequest(member._id)}
                        className="flex items-center gap-1 rounded-xl bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 shadow-xs transition-colors cursor-pointer"
                      >
                        <UserPlus className="h-3.5 w-3.5" />
                        <span>Add Friend</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Requests */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">
            Incoming Requests ({receivedRequests.length})
          </h2>

          {receivedRequests.length > 0 ? (
            <div className="space-y-3">
              {receivedRequests.map((req) => {
                const requester = otherUsers.find((u) => u._id === req.fromUserId);
                if (!requester) return null;

                return (
                  <div
                    key={req.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs"
                  >
                    <div
                      onClick={() => openUserProfile(requester)}
                      className="flex items-center gap-3 cursor-pointer group"
                    >
                      {requester.photo ? (
                        <img
                          src={requester.photo}
                          alt={requester.name}
                          className="h-11 w-11 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                        />
                      ) : (
                        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-indigo-600 text-sm font-bold text-white">
                          {requester.name.charAt(0)}
                        </div>
                      )}
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 transition-colors">
                          {requester.name}
                        </p>
                        <p className="text-[11px] text-slate-400">{requester.handle}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => acceptFriendRequest(req.id)}
                        className="flex items-center gap-1 rounded-xl bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer"
                      >
                        <UserCheck className="h-3.5 w-3.5" />
                        <span>Accept</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => cancelFriendRequest(req.fromUserId)}
                        className="rounded-xl bg-slate-100 dark:bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-rose-50 hover:text-rose-600 cursor-pointer"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
              No pending friend requests at this time.
            </div>
          )}

          {/* Sent Requests */}
          {sentRequests.length > 0 && (
            <div className="pt-4 space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">
                Sent Requests ({sentRequests.length})
              </h2>
              <div className="space-y-2">
                {sentRequests.map((req) => {
                  const target = otherUsers.find((u) => u._id === req.toUserId);
                  if (!target) return null;
                  return (
                    <div
                      key={req.id}
                      className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                    >
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {target.name} ({target.handle})
                      </span>
                      <button
                        type="button"
                        onClick={() => cancelFriendRequest(req.toUserId)}
                        className="text-xs text-rose-500 hover:underline cursor-pointer"
                      >
                        Cancel Request
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: My Friends */}
      {activeTab === 'friends' && (
        <div className="space-y-4">
          {myFriendsList.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {myFriendsList.map((member) => (
                <div
                  key={member._id}
                  className="flex items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs"
                >
                  <div
                    onClick={() => openUserProfile(member)}
                    className="flex items-center gap-3 cursor-pointer group min-w-0"
                  >
                    {member.photo ? (
                      <img
                        src={member.photo}
                        alt={member.name}
                        className="h-11 w-11 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                      />
                    ) : (
                      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-indigo-600 text-sm font-bold text-white">
                        {member.name.charAt(0)}
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 truncate transition-colors">
                        {member.name}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">{member.handle}</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeFriend(member._id)}
                    className="flex items-center gap-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-700 dark:text-slate-300 hover:text-rose-600 px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer"
                    title="Unfriend"
                  >
                    <UserX className="h-3.5 w-3.5" />
                    <span>Unfriend</span>
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
              You haven't connected with friends yet. Send requests from the Explore Network tab!
            </div>
          )}
        </div>
      )}
    </div>
  );
};
