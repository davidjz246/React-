import React, { useState, useRef } from 'react';
import { Post, User } from '../types';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { CommentItem } from './CommentItem';
import {
  ArrowLeft,
  Heart,
  Share2,
  Bookmark,
  Send,
  Trash2,
  Edit3,
  Maximize2,
  Check,
  UserPlus,
  UserCheck,
} from 'lucide-react';

interface PostDetailsViewProps {
  post: Post;
  onBack: () => void;
  onOpenImage?: (url: string) => void;
  onEditPost?: (post: Post) => void;
}

export const PostDetailsView: React.FC<PostDetailsViewProps> = ({
  post,
  onBack,
  onOpenImage,
  onEditPost,
}) => {
  const { user, networkUsers, getFriendshipState, sendFriendRequest, removeFriend } = useAuth();
  const { toggleLikePost, toggleSavePost, addComment, deletePost, sharePost, openUserProfile } = usePosts();
  const [commentText, setCommentText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const commentInputRef = useRef<HTMLTextAreaElement>(null);

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      await addComment(post._id, commentText.trim());
      setCommentText('');
      setTimeout(() => {
        commentInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 100);
    } catch (err) {
      console.error('Failed to post comment:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleShare = async () => {
    await sharePost(post);
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const isAuthor =
    user && (user._id === post.user?._id || user.email === post.user?.email || (user.name && user.name === post.user?.name));

  const friendState = post.user?._id ? getFriendshipState(post.user._id) : 'none';

  const handleAuthorClick = () => {
    if (post.user) {
      const existing = networkUsers.find((u) => u._id === post.user._id);
      const userObj: User = existing || {
        _id: post.user._id,
        name: post.user.name,
        email: post.user.email || '',
        photo: post.user.photo,
        handle: post.user.handle,
        followersCount: 0,
        followingCount: 0,
      };
      openUserProfile(userObj);
    }
  };

  const handleDeletePost = async () => {
    if (confirm('Are you sure you want to delete this publication?')) {
      await deletePost(post._id);
      onBack();
    }
  };

  const formattedDate = new Date(post.createdAt || Date.now()).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Return Button */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-white shadow-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Feed</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="font-mono tabular-nums">{post.comments?.length || 0} Comments</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{post.likesCount || 0} Likes</span>
        </div>
      </div>

      {/* Main Single Post Container */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 p-6 shadow-sm">
        {/* Author Header */}
        <div className="flex items-center justify-between gap-4 mb-5">
          <div className="flex items-center gap-3.5">
            <div
              onClick={handleAuthorClick}
              className="cursor-pointer transition-transform hover:scale-105"
              title={`View ${post.user?.name}'s profile`}
            >
              {post.user?.photo ? (
                <img
                  src={post.user.photo}
                  alt={post.user.name}
                  referrerPolicy="no-referrer"
                  className="h-12 w-12 rounded-full object-cover ring-2 ring-indigo-500/30"
                />
              ) : (
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-600 to-violet-700 text-base font-bold text-white shadow-inner">
                  {post.user?.name?.charAt(0) || 'U'}
                </div>
              )}
            </div>

            <div>
              <h2
                onClick={handleAuthorClick}
                className="text-base font-bold text-slate-900 dark:text-slate-100 font-display hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer transition-colors"
              >
                {post.user?.name || 'Creator'}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                <span>{post.user?.handle || '@creator'}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">{formattedDate}</span>
                {post.tags && post.tags.length > 0 && post.tags[0] && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                      {post.tags[0].replace(/^#+/, '')}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            {!isAuthor && post.user?._id && (
              <button
                type="button"
                onClick={() => {
                  if (friendState === 'friends') {
                    removeFriend(post.user._id);
                  } else if (friendState === 'none') {
                    sendFriendRequest(post.user._id);
                  }
                }}
                className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
                  friendState === 'friends'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400'
                    : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-xs'
                }`}
              >
                {friendState === 'friends' ? <UserCheck className="h-3.5 w-3.5" /> : <UserPlus className="h-3.5 w-3.5" />}
                <span>{friendState === 'friends' ? 'Friends' : 'Add Friend'}</span>
              </button>
            )}

            {isAuthor && (
              <div className="flex items-center gap-2">
                {onEditPost && (
                  <button
                    type="button"
                    onClick={() => onEditPost(post)}
                    className="flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                    <span>Edit</span>
                  </button>
                )}

                {showDeleteConfirm ? (
                  <div className="flex items-center gap-1.5 bg-rose-50 dark:bg-rose-950/60 p-1.5 rounded-xl border border-rose-200 dark:border-rose-900">
                    <span className="text-xs font-semibold text-rose-700 dark:text-rose-300 px-1">Delete?</span>
                    <button
                      type="button"
                      onClick={async () => {
                        await deletePost(post._id);
                        onBack();
                      }}
                      className="rounded-lg bg-rose-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-rose-500 cursor-pointer shadow-xs"
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowDeleteConfirm(false)}
                      className="rounded-lg bg-slate-200 dark:bg-slate-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowDeleteConfirm(true)}
                    className="flex items-center gap-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 px-3 py-1.5 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/50 transition-colors cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Post Text Body */}
        {post.body && (
          <p className="text-base leading-relaxed text-slate-900 dark:text-slate-100 whitespace-pre-line mb-5">
            {post.body}
          </p>
        )}

        {/* Media Image */}
        {post.image && (
          <div className="relative mb-6 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 group">
            <img
              src={post.image}
              alt="Post content"
              referrerPolicy="no-referrer"
              className="w-full max-h-[600px] object-cover cursor-pointer"
              onClick={() => onOpenImage && onOpenImage(post.image!)}
            />
            <button
              type="button"
              onClick={() => onOpenImage && onOpenImage(post.image!)}
              className="absolute bottom-3 right-3 rounded-lg bg-slate-950/80 p-2 text-slate-300 opacity-0 group-hover:opacity-100 backdrop-blur transition-opacity hover:text-white cursor-pointer"
            >
              <Maximize2 className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* Engagement Stats & Actions */}
        <div className="flex items-center justify-between border-y border-slate-100 dark:border-slate-800 py-3 text-xs text-slate-600 dark:text-slate-300">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => toggleLikePost(post._id)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition-colors cursor-pointer ${
                post.isLiked
                  ? 'text-rose-600 dark:text-rose-400 font-semibold bg-rose-50 dark:bg-rose-950/30'
                  : 'hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Heart className={`h-4 w-4 ${post.isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span className="tabular-nums font-mono">{post.likesCount || 0}</span>
              <span>Likes</span>
            </button>

            <button
              type="button"
              onClick={() => toggleSavePost(post._id)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition-colors cursor-pointer ${
                post.isSaved
                  ? 'text-amber-600 dark:text-amber-400 font-semibold bg-amber-50 dark:bg-amber-950/30'
                  : 'hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Bookmark className={`h-4 w-4 ${post.isSaved ? 'fill-amber-500 text-amber-500' : ''}`} />
              <span>{post.isSaved ? 'Saved' : 'Save'}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleShare}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition-colors cursor-pointer ${
              copied
                ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 font-semibold'
                : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Share post to your profile"
          >
            {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Share2 className="h-4 w-4" />}
            <span>{copied ? 'Shared to Profile!' : 'Share'}</span>
          </button>
        </div>

        {/* Full Comment Thread */}
        <div className="mt-6 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-200">
              Discussion ({post.comments?.length || 0})
            </h3>
            <span className="text-xs text-slate-400">Chronological thread</span>
          </div>

          {/* Comment Composer */}
          <form onSubmit={handleCommentSubmit} className="flex gap-3">
            <div className="relative shrink-0 pt-1">
              {user?.photo ? (
                <img
                  src={user.photo}
                  alt={user.name}
                  referrerPolicy="no-referrer"
                  className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                />
              ) : (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                  {user?.name?.charAt(0) || 'U'}
                </div>
              )}
            </div>

            <div className="relative flex-1">
              <textarea
                ref={commentInputRef}
                rows={2}
                placeholder="Share your perspective on this post..."
                value={commentText}
                onChange={(e) => {
                  setCommentText(e.target.value);
                  commentInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }}
                className="w-full rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 pr-12 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:border-indigo-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!commentText.trim() || isSubmitting}
                className="absolute bottom-3 right-3 rounded-lg bg-indigo-600 p-1.5 text-white hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 transition-colors cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-2 divide-y divide-slate-100 dark:divide-slate-800/50">
            {post.comments && post.comments.length > 0 ? (
              post.comments.map((comm) => (
                <CommentItem key={comm._id} comment={comm} postId={post._id} />
              ))
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">
                No replies yet. Be the first to share your perspective!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
