import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { useTheme } from '../context/ThemeContext';
import { useNotifications } from '../context/NotificationContext';
import { NotificationDropdown } from './NotificationDropdown';
import {
  Search,
  Plus,
  Home,
  Bookmark,
  User as UserIcon,
  Users,
  LogOut,
  KeyRound,
  Sun,
  Moon,
  Menu,
  X,
  Bell,
} from 'lucide-react';

interface NavbarProps {
  onOpenAuth: (mode?: 'login' | 'register' | 'change-password') => void;
  onOpenCreateModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAuth, onOpenCreateModal }) => {
  const { user, isAuthenticated, logout } = useAuth();
  const { activeView, setActiveView, searchQuery, setSearchQuery } = usePosts();
  const { theme, toggleTheme } = useTheme();
  const { unreadCount } = useNotifications();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotificationMenu, setShowNotificationMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotificationMenu(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setShowProfileMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800/80 bg-white/90 dark:bg-slate-950/85 backdrop-blur-md transition-colors">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setActiveView('feed');
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-2.5 text-left group cursor-pointer"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 font-bold text-white shadow-md shadow-indigo-600/30 group-hover:from-indigo-500 group-hover:to-violet-500 transition-colors font-display">
              O
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white font-display">
              Oasis
            </span>
          </button>
        </div>

        {/* Zone 2: Clean Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600 dark:text-slate-400">
          <button
            type="button"
            onClick={() => setActiveView('feed')}
            className={`flex items-center gap-2 transition-colors cursor-pointer ${
              activeView === 'feed'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Home className="h-4 w-4" />
            <span>Feed</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('friends')}
            className={`flex items-center gap-2 transition-colors cursor-pointer ${
              activeView === 'friends'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Users className="h-4 w-4" />
            <span>Friends</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('saved')}
            className={`flex items-center gap-2 transition-colors cursor-pointer ${
              activeView === 'saved'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Bookmark className="h-4 w-4" />
            <span>Saved</span>
          </button>

          {isAuthenticated && (
            <button
              type="button"
              onClick={() => setActiveView('profile')}
              className={`flex items-center gap-2 transition-colors cursor-pointer ${
                activeView === 'profile'
                  ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                  : 'hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <UserIcon className="h-4 w-4" />
              <span>Profile</span>
            </button>
          )}
        </nav>

        {/* Zone 3: Search Bar, Notifications, Theme Toggle, & Account Actions */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Search Input */}
          <div className="relative hidden sm:block w-40 lg:w-52">
            <input
              type="text"
              placeholder="Search feed & creators..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 py-1.5 pl-8 pr-3 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:border-indigo-500 focus:outline-none transition-colors"
            />
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          </div>

          {/* Real-Time Notification Bell */}
          {isAuthenticated && (
            <div className="relative" ref={notifRef}>
              <button
                type="button"
                onClick={() => {
                  setShowNotificationMenu(!showNotificationMenu);
                  setShowProfileMenu(false);
                }}
                className={`relative flex items-center justify-center h-9 w-9 rounded-xl border transition-all cursor-pointer ${
                  showNotificationMenu
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-300 dark:border-indigo-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400'
                }`}
                title="Notifications"
                aria-label="View notifications"
              >
                <Bell className="h-4 w-4" />

                {/* Unread badge & pulsing indicator */}
                {unreadCount > 0 && (
                  <>
                    <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white shadow-xs animate-in zoom-in">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                    <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-rose-400 animate-ping opacity-75" />
                  </>
                )}
              </button>

              {/* Notification Popover Dropdown */}
              {showNotificationMenu && (
                <div className="absolute right-0 sm:-right-4 top-11 z-50">
                  <NotificationDropdown onClose={() => setShowNotificationMenu(false)} />
                </div>
              )}
            </div>
          )}

          {/* Theme Toggle Button (Light / Night Mode) */}
          <button
            type="button"
            onClick={toggleTheme}
            className="flex items-center justify-center h-9 w-9 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors cursor-pointer"
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="h-4 w-4 text-amber-400" />
            ) : (
              <Moon className="h-4 w-4 text-slate-700" />
            )}
          </button>

          {/* Quick Create Trigger */}
          {onOpenCreateModal && (
            <button
              type="button"
              onClick={onOpenCreateModal}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">New Post</span>
            </button>
          )}

          {/* User Account / Auth Trigger */}
          {isAuthenticated && user ? (
            <div className="relative" ref={profileRef}>
              <button
                type="button"
                onClick={() => {
                  setShowProfileMenu(!showProfileMenu);
                  setShowNotificationMenu(false);
                }}
                className="flex items-center gap-2 rounded-xl p-1 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors cursor-pointer"
              >
                {user.photo ? (
                  <img
                    src={user.photo}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="h-8 w-8 rounded-full object-cover ring-2 ring-indigo-500/30"
                  />
                ) : (
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-700 text-xs font-bold text-white">
                    {user.name?.charAt(0) || 'U'}
                  </div>
                )}
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 top-11 z-50 w-52 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 p-2 shadow-2xl">
                  <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {user.name}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {user.email}
                    </p>
                  </div>

                  <div className="py-1 text-xs">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveView('profile');
                        setShowProfileMenu(false);
                      }}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-white rounded-lg cursor-pointer"
                    >
                      <UserIcon className="h-3.5 w-3.5 text-indigo-500" />
                      <span>My Profile</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onOpenAuth('change-password');
                        setShowProfileMenu(false);
                      }}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-white rounded-lg cursor-pointer"
                    >
                      <KeyRound className="h-3.5 w-3.5 text-amber-500" />
                      <span>Change Password</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        logout();
                        setShowProfileMenu(false);
                      }}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg cursor-pointer"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onOpenAuth('login')}
                className="rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors whitespace-nowrap cursor-pointer"
              >
                Sign In / Sign Up
              </button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden rounded-lg p-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-3 space-y-2 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setActiveView('feed');
              setMobileMenuOpen(false);
            }}
            className="flex w-full items-center gap-2.5 py-2 text-slate-700 dark:text-slate-300"
          >
            <Home className="h-4 w-4" />
            <span>Feed</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveView('friends');
              setMobileMenuOpen(false);
            }}
            className="flex w-full items-center gap-2.5 py-2 text-slate-700 dark:text-slate-300"
          >
            <Users className="h-4 w-4" />
            <span>Friends</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveView('saved');
              setMobileMenuOpen(false);
            }}
            className="flex w-full items-center gap-2.5 py-2 text-slate-700 dark:text-slate-300"
          >
            <Bookmark className="h-4 w-4" />
            <span>Saved Bookmarks</span>
          </button>
          {isAuthenticated ? (
            <button
              type="button"
              onClick={() => {
                setActiveView('profile');
                setMobileMenuOpen(false);
              }}
              className="flex w-full items-center gap-2.5 py-2 text-slate-700 dark:text-slate-300"
            >
              <UserIcon className="h-4 w-4" />
              <span>My Profile</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onOpenAuth('login');
                setMobileMenuOpen(false);
              }}
              className="flex w-full items-center gap-2.5 py-2 text-indigo-600 font-bold"
            >
              <span>Sign In / Create Account</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};

