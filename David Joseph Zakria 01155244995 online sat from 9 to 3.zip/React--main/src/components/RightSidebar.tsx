import React from 'react';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { Users, UserPlus, UserCheck, Flame, Compass } from 'lucide-react';

export const RightSidebar: React.FC = () => {
  const { user, networkUsers, getFriendshipState, sendFriendRequest, removeFriend } = useAuth();
  const { openUserProfile, setActiveView } = usePosts();

  const suggestedUsers = networkUsers.filter((u) => u._id !== user?._id).slice(0, 3);

  return (
    <aside className="sticky top-20 hidden lg:flex flex-col gap-4 w-80 shrink-0">
      {/* Recommended Network Members */}
      <div className="rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 p-4 space-y-3.5 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">
            People in Network
          </h3>
          <Users className="h-3.5 w-3.5 text-slate-400" />
        </div>

        <div className="space-y-3">
          {suggestedUsers.map((member) => {
            const status = getFriendshipState(member._id);
            return (
              <div
                key={member._id}
                className="flex items-center justify-between gap-3 text-xs"
              >
                <div
                  onClick={() => openUserProfile(member)}
                  className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
                >
                  {member.photo ? (
                    <img
                      src={member.photo}
                      alt={member.name}
                      referrerPolicy="no-referrer"
                      className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-800 shrink-0"
                    />
                  ) : (
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white shrink-0">
                      {member.name.charAt(0)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 dark:text-slate-200 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                      {member.name}
                    </p>
                    <p className="text-[11px] text-slate-400 truncate">
                      {member.handle || '@member'}
                    </p>
                  </div>
                </div>

                {status === 'friends' ? (
                  <button
                    type="button"
                    onClick={() => removeFriend(member._id)}
                    className="flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 hover:bg-rose-50 hover:text-rose-600 transition-all shrink-0 cursor-pointer"
                    title="Unfriend"
                  >
                    <UserCheck className="h-3 w-3" />
                    <span>Friends</span>
                  </button>
                ) : status === 'pending_sent' ? (
                  <span className="text-[11px] text-slate-400 font-medium px-2 py-1">Pending</span>
                ) : (
                  <button
                    type="button"
                    onClick={() => sendFriendRequest(member._id)}
                    className="flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-500 shadow-xs transition-all shrink-0 cursor-pointer"
                  >
                    <UserPlus className="h-3 w-3" />
                    <span>Add</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => setActiveView('friends')}
          className="w-full text-center text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline pt-1 block cursor-pointer"
        >
          View All Members ({networkUsers.length}) &rarr;
        </button>
      </div>

      {/* Community Discovery Card */}
      <div className="rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 p-4 space-y-2.5 shadow-xs">
        <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
          <Compass className="h-4 w-4" />
          <span className="text-xs font-bold uppercase tracking-wider font-mono">
            Explore Community
          </span>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          Discover visual creations, photo projects, and trending community debates.
        </p>
        <button
          type="button"
          onClick={() => setActiveView('trending')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline pt-1 cursor-pointer"
        >
          <Flame className="h-3.5 w-3.5 text-amber-500" />
          <span>View Trending Discussions</span>
        </button>
      </div>

      {/* Quiet Footer */}
      <div className="px-2 text-[11px] text-slate-400 dark:text-slate-500 space-y-1">
        <div className="flex items-center gap-2">
          <span>Privacy</span>
          <span aria-hidden="true">·</span>
          <span>Terms</span>
          <span aria-hidden="true">·</span>
          <span>Oasis Network</span>
        </div>
        <p>© 2026 Oasis. Built with clean composure.</p>
      </div>
    </aside>
  );
};
