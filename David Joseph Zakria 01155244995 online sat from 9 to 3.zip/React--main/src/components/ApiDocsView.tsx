import React, { useState } from 'react';
import { apiService, getStoredToken } from '../services/api';
import { Terminal, Send, CheckCircle2, AlertCircle, Copy, Check, ExternalLink, Code } from 'lucide-react';

export const ApiDocsView: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'auth' | 'posts' | 'comments'>('all');
  const [testResult, setTestResult] = useState<{ id: string; status: number; data: any; loading: boolean } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const token = getStoredToken();

  const endpoints = [
    // 1. Auth Endpoints
    {
      id: 'auth_signup',
      category: 'auth',
      method: 'POST',
      path: '/users/signup',
      title: 'User Registration',
      description: 'Creates a new user account on the social platform.',
      headers: { 'Content-Type': 'application/json' },
      body: {
        name: 'Alexa Chen',
        email: 'alexa.chen@example.com',
        password: 'Password123!',
        rePassword: 'Password123!',
        dateOfBirth: '1998-05-12',
        gender: 'female'
      },
      response: {
        message: 'success',
        user: { _id: '65f8...', name: 'Alexa Chen', email: 'alexa.chen@example.com' }
      },
      testable: false,
    },
    {
      id: 'auth_signin',
      category: 'auth',
      method: 'POST',
      path: '/users/signin',
      title: 'User Login',
      description: 'Authenticates a user and returns a bearer JWT token.',
      headers: { 'Content-Type': 'application/json' },
      body: {
        email: 'alexa.chen@example.com',
        password: 'Password123!'
      },
      response: {
        message: 'success',
        token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
      },
      testable: false,
    },
    {
      id: 'auth_change_password',
      category: 'auth',
      method: 'PATCH',
      path: '/users/change-password',
      title: 'Change Password',
      description: 'Updates the user password given their current credentials.',
      headers: { 'Content-Type': 'application/json', token: '<USER_TOKEN>' },
      body: {
        password: 'OldPassword123!',
        newPassword: 'NewPassword123!'
      },
      response: {
        message: 'success',
        token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
      },
      testable: false,
    },
    {
      id: 'auth_profile_data',
      category: 'auth',
      method: 'GET',
      path: '/users/profile-data',
      title: 'Get User Profile Data',
      description: 'Retrieves current logged-in user details and metadata.',
      headers: { token: '<USER_TOKEN>' },
      response: {
        message: 'success',
        user: { _id: '65f8...', name: 'Alexa Chen', email: '...', photo: '...' }
      },
      testable: true,
      testFn: async () => {
        return await apiService.getProfileData();
      }
    },
    {
      id: 'auth_upload_photo',
      category: 'auth',
      method: 'PUT',
      path: '/users/upload-profile-photo',
      title: 'Upload Profile Photo',
      description: 'Uploads an avatar photo file via multipart/form-data.',
      headers: { token: '<USER_TOKEN>' },
      bodyDescription: 'FormData: photo (File)',
      response: {
        message: 'success',
        user: { photo: 'https://...' }
      },
      testable: false,
    },

    // 2. Posts Endpoints
    {
      id: 'posts_get_all',
      category: 'posts',
      method: 'GET',
      path: '/posts?limit=50&page=1',
      title: 'Fetch All Posts (Feed)',
      description: 'Returns a paginated stream of community posts with comments.',
      headers: { token: '<USER_TOKEN>' },
      response: {
        message: 'success',
        paginationInfo: { currentPage: 1, numberOfPages: 5, limit: 50, total: 240 },
        posts: [
          {
            _id: '65f8...',
            body: 'Exploring structural architecture...',
            image: 'https://...',
            user: { _id: '...', name: 'Marcus Vance' },
            createdAt: '2026-03-20T...',
            comments: []
          }
        ]
      },
      testable: true,
      testFn: async () => {
        return await apiService.getPosts(1, 5);
      }
    },
    {
      id: 'posts_get_single',
      category: 'posts',
      method: 'GET',
      path: '/posts/{postId}',
      title: 'Get Single Post Details',
      description: 'Fetches full details of a specific post including all comments.',
      headers: { token: '<USER_TOKEN>' },
      response: {
        message: 'success',
        post: {
          _id: '65f8...',
          body: 'Detailed design writeup...',
          comments: []
        }
      },
      testable: false,
    },
    {
      id: 'posts_create',
      category: 'posts',
      method: 'POST',
      path: '/posts',
      title: 'Create New Post',
      description: 'Creates a post with body text and optional photo attachment.',
      headers: { token: '<USER_TOKEN>' },
      bodyDescription: 'FormData: body (string), image (File, optional)',
      response: {
        message: 'success',
        post: { _id: '65f8...', body: '...' }
      },
      testable: false,
    },
    {
      id: 'posts_update',
      category: 'posts',
      method: 'PUT',
      path: '/posts/{postId}',
      title: 'Update Existing Post',
      description: 'Updates body text or replaces image for an existing post.',
      headers: { token: '<USER_TOKEN>' },
      body: { body: 'Updated post content string' },
      response: {
        message: 'success',
        post: { _id: '65f8...', body: 'Updated...' }
      },
      testable: false,
    },
    {
      id: 'posts_delete',
      category: 'posts',
      method: 'DELETE',
      path: '/posts/{postId}',
      title: 'Delete Post',
      description: 'Removes the post created by the logged-in user.',
      headers: { token: '<USER_TOKEN>' },
      response: {
        message: 'success'
      },
      testable: false,
    },
    {
      id: 'posts_user_timeline',
      category: 'posts',
      method: 'GET',
      path: '/users/{userId}/posts',
      title: 'Get User Posts Timeline',
      description: 'Fetches timeline of posts authored by a specific user.',
      headers: { token: '<USER_TOKEN>' },
      response: {
        message: 'success',
        posts: []
      },
      testable: false,
    },

    // 3. Comments Endpoints
    {
      id: 'comments_create',
      category: 'comments',
      method: 'POST',
      path: '/comments',
      title: 'Create Comment',
      description: 'Appends a comment to a specific post.',
      headers: { 'Content-Type': 'application/json', token: '<USER_TOKEN>' },
      body: {
        content: 'This architectural detail is stunning!',
        post: '65f891a...'
      },
      response: {
        message: 'success',
        comment: {
          _id: '65f9...',
          content: 'This architectural detail is stunning!',
          commentCreator: { _id: '...', name: 'Alexa' }
        }
      },
      testable: false,
    },
    {
      id: 'comments_update',
      category: 'comments',
      method: 'PUT',
      path: '/comments/{commentId}',
      title: 'Update Comment',
      description: 'Updates content of an existing comment.',
      headers: { 'Content-Type': 'application/json', token: '<USER_TOKEN>' },
      body: {
        content: 'Updated comment content text'
      },
      response: {
        message: 'success',
        comment: { _id: '...', content: 'Updated...' }
      },
      testable: false,
    },
    {
      id: 'comments_delete',
      category: 'comments',
      method: 'DELETE',
      path: '/comments/{commentId}',
      title: 'Delete Comment',
      description: 'Deletes a comment created by the authenticated user.',
      headers: { token: '<USER_TOKEN>' },
      response: {
        message: 'success'
      },
      testable: false,
    },
  ];

  const filteredEndpoints = endpoints.filter((ep) => {
    if (activeCategory === 'all') return true;
    return ep.category === activeCategory;
  });

  const handleRunTest = async (ep: any) => {
    if (!ep.testFn) return;
    setTestResult({ id: ep.id, status: 0, data: null, loading: true });
    try {
      const data = await ep.testFn();
      setTestResult({ id: ep.id, status: 200, data, loading: false });
    } catch (err: any) {
      setTestResult({ id: ep.id, status: 500, data: { error: err.message }, loading: false });
    }
  };

  const handleCopyCurl = (ep: any) => {
    const curl = `curl -X ${ep.method} "https://route-posts.routemisr.com${ep.path}" \\
  -H "token: ${token || 'YOUR_JWT_TOKEN'}" ${
      ep.body ? `\\\n  -H "Content-Type: application/json" \\\n  -d '${JSON.stringify(ep.body)}'` : ''
    }`;
    navigator.clipboard?.writeText(curl);
    setCopiedId(ep.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getMethodBadge = (m: string) => {
    switch (m) {
      case 'GET':
        return 'bg-emerald-950/80 text-emerald-400 border-emerald-800/80';
      case 'POST':
        return 'bg-indigo-950/80 text-indigo-400 border-indigo-800/80';
      case 'PUT':
        return 'bg-amber-950/80 text-amber-400 border-amber-800/80';
      case 'PATCH':
        return 'bg-cyan-950/80 text-cyan-400 border-cyan-800/80';
      case 'DELETE':
        return 'bg-rose-950/80 text-rose-400 border-rose-800/80';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Overview Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Terminal className="h-5 w-5 text-indigo-400" />
              <h1 className="text-lg font-bold text-slate-100 font-display">
                Route Posts Backend API Architecture
              </h1>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
              Complete reference for all REST endpoints powering Authentication, Feed generation, Posts CRUD, and Comments threading connecting directly to <code>https://route-posts.routemisr.com</code>.
            </p>
          </div>

          <a
            href="https://route-posts.routemisr.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600/20 border border-indigo-500/30 px-3.5 py-2 text-xs font-semibold text-indigo-300 hover:bg-indigo-600/30 transition-colors shrink-0"
          >
            <span>Live Base URL</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>

        {/* Filter Tabs */}
        <div className="mt-5 flex items-center gap-2 border-t border-slate-800 pt-4 text-xs font-semibold">
          {(['all', 'auth', 'posts', 'comments'] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`rounded-lg px-3 py-1.5 capitalize transition-colors ${
                activeCategory === cat
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat} ({endpoints.filter((e) => cat === 'all' || e.category === cat).length})
            </button>
          ))}
        </div>
      </div>

      {/* Endpoints List */}
      <div className="space-y-4">
        {filteredEndpoints.map((ep) => (
          <div
            key={ep.id}
            className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-sm space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 flex-wrap">
                <span
                  className={`rounded-lg border px-2.5 py-0.5 text-xs font-mono font-bold ${getMethodBadge(
                    ep.method
                  )}`}
                >
                  {ep.method}
                </span>
                <span className="font-mono text-xs font-semibold text-slate-200">
                  {ep.path}
                </span>
                <span className="text-xs text-slate-500 hidden md:inline" aria-hidden="true">
                  ·
                </span>
                <span className="text-xs font-medium text-slate-300">
                  {ep.title}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopyCurl(ep)}
                  className="flex items-center gap-1.5 rounded-lg bg-slate-950 border border-slate-800 px-2.5 py-1 text-xs text-slate-400 hover:text-slate-200"
                  title="Copy cURL snippet"
                >
                  {copiedId === ep.id ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedId === ep.id ? 'Copied' : 'cURL'}</span>
                </button>

                {ep.testable && (
                  <button
                    type="button"
                    onClick={() => handleRunTest(ep)}
                    className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1 text-xs font-semibold text-white hover:bg-indigo-500 shadow-xs transition-colors"
                  >
                    <Send className="h-3 w-3" />
                    <span>Test Endpoint</span>
                  </button>
                )}
              </div>
            </div>

            <p className="text-xs text-slate-400">{ep.description}</p>

            {/* Request & Response Schemas */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs">
              {/* Request info */}
              <div className="rounded-xl bg-slate-950 border border-slate-800 p-3">
                <div className="text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center justify-between">
                  <span>REQUEST SPECIFICATION</span>
                  {ep.headers.token && <span className="text-amber-400 font-mono">Requires Token</span>}
                </div>
                {ep.body && (
                  <pre className="text-[11px] text-slate-300 font-mono bg-slate-900/60 p-2 rounded overflow-x-auto max-h-36">
                    {JSON.stringify(ep.body, null, 2)}
                  </pre>
                )}
                {ep.bodyDescription && (
                  <p className="text-xs text-indigo-300 font-mono mt-1">{ep.bodyDescription}</p>
                )}
                {!ep.body && !ep.bodyDescription && (
                  <span className="text-slate-500 italic">No request body required</span>
                )}
              </div>

              {/* Response sample */}
              <div className="rounded-xl bg-slate-950 border border-slate-800 p-3">
                <div className="text-[11px] font-semibold text-slate-400 mb-1.5">
                  RESPONSE PAYLOAD
                </div>
                <pre className="text-[11px] text-slate-300 font-mono bg-slate-900/60 p-2 rounded overflow-x-auto max-h-36">
                  {JSON.stringify(ep.response, null, 2)}
                </pre>
              </div>
            </div>

            {/* Live Test Outcome Window */}
            {testResult && testResult.id === ep.id && (
              <div className="rounded-xl bg-slate-950 border border-indigo-500/40 p-3.5 space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    {testResult.loading ? (
                      <span className="text-indigo-400 animate-pulse font-mono">
                        Querying https://route-posts.routemisr.com{ep.path}...
                      </span>
                    ) : testResult.status === 200 ? (
                      <div className="flex items-center gap-1.5 text-emerald-400 font-semibold font-mono">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>Status: 200 OK</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-rose-400 font-semibold font-mono">
                        <AlertCircle className="h-4 w-4" />
                        <span>Remote API Error</span>
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setTestResult(null)}
                    className="text-slate-500 hover:text-slate-300 text-xs"
                  >
                    Dismiss
                  </button>
                </div>

                {!testResult.loading && (
                  <pre className="text-[11px] text-emerald-300 font-mono bg-slate-900 p-2.5 rounded max-h-48 overflow-y-auto">
                    {JSON.stringify(testResult.data, null, 2)}
                  </pre>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
