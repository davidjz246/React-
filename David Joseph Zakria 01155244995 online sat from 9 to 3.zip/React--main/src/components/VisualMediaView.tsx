import React, { useState } from 'react';
import { usePosts } from '../context/PostContext';
import { Post } from '../types';
import { Image as ImageIcon, Heart, MessageCircle, Maximize2, ArrowLeft, Grid, Layers } from 'lucide-react';
import { PostCard } from './PostCard';

interface VisualMediaViewProps {
  onOpenDetails: (post: Post) => void;
  onOpenImage: (url: string) => void;
  onEditPost: (post: Post) => void;
}

export const VisualMediaView: React.FC<VisualMediaViewProps> = ({
  onOpenDetails,
  onOpenImage,
  onEditPost,
}) => {
  const { mediaPosts, setActiveView, openUserProfile } = usePosts();
  const [layoutMode, setLayoutMode] = useState<'grid' | 'stream'>('grid');

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-cyan-500/10 via-white dark:via-slate-900 to-white dark:to-slate-900 border border-cyan-500/20 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-md shadow-cyan-600/30">
              <ImageIcon className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                Visual Media Gallery
              </h1>
              <p className="text-xs text-slate-500">
                Dedicated stream of photographic projects, architectural captures, and creative uploads
              </p>
            </div>
          </div>

          {/* Layout controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setLayoutMode('grid')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  layoutMode === 'grid' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-xs' : 'text-slate-400'
                }`}
                title="Grid layout"
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setLayoutMode('stream')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  layoutMode === 'stream' ? 'bg-white dark:bg-slate-700 text-cyan-600 shadow-xs' : 'text-slate-400'
                }`}
                title="Stream layout"
              >
                <Layers className="h-4 w-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => setActiveView('feed')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Feed</span>
            </button>
          </div>
        </div>
      </div>

      {/* Media Collection */}
      {mediaPosts.length > 0 ? (
        layoutMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {mediaPosts.map((post) => (
              <div
                key={post._id}
                className="group relative overflow-hidden rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs transition-all hover:shadow-md"
              >
                {/* Image */}
                <div
                  className="relative aspect-[4/3] overflow-hidden bg-slate-100 dark:bg-slate-950 cursor-pointer"
                  onClick={() => onOpenImage(post.image!)}
                >
                  <img
                    src={post.image}
                    alt={post.body || 'Media upload'}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenImage(post.image!);
                    }}
                    className="absolute right-2.5 top-2.5 rounded-full bg-slate-950/70 p-1.5 text-white opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur cursor-pointer"
                  >
                    <Maximize2 className="h-4 w-4" />
                  </button>
                </div>

                {/* Card footer */}
                <div className="p-3.5 space-y-2">
                  <div
                    onClick={() => post.user && openUserProfile(post.user as any)}
                    className="flex items-center gap-2 cursor-pointer"
                  >
                    {post.user.photo ? (
                      <img
                        src={post.user.photo}
                        alt={post.user.name}
                        className="h-6 w-6 rounded-full object-cover"
                      />
                    ) : (
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-indigo-600 text-[10px] font-bold text-white">
                        {post.user.name?.charAt(0) || 'U'}
                      </div>
                    )}
                    <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate hover:text-cyan-600 transition-colors">
                      {post.user.name}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                    {post.body}
                  </p>

                  <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-2 text-xs text-slate-400">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 font-mono">
                        <Heart className="h-3.5 w-3.5 text-rose-500" />
                        {post.likesCount}
                      </span>
                      <span className="flex items-center gap-1 font-mono">
                        <MessageCircle className="h-3.5 w-3.5" />
                        {post.comments?.length || 0}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenDetails(post)}
                      className="text-xs font-semibold text-cyan-600 dark:text-cyan-400 hover:underline cursor-pointer"
                    >
                      View Thread &rarr;
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {mediaPosts.map((post) => (
              <PostCard
                key={post._id}
                post={post}
                onOpenDetails={onOpenDetails}
                onOpenImage={onOpenImage}
                onEditPost={onEditPost}
              />
            ))}
          </div>
        )
      ) : (
        <div className="rounded-2xl bg-white dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 p-12 text-center space-y-3">
          <ImageIcon className="mx-auto h-8 w-8 text-cyan-500" />
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            No media posts yet
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Upload images when creating posts in the discover feed to populate this visual gallery!
          </p>
        </div>
      )}
    </div>
  );
};
