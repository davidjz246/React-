import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import {
  Image as ImageIcon,
  Send,
  X,
  Compass,
  Check,
  Plus,
} from 'lucide-react';

export const CreatePostBox: React.FC = () => {
  const { user } = useAuth();
  const { createPost, openUserProfile } = usePosts();

  const [bodyText, setBodyText] = useState('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '4:3' | '1:1' | '9:16'>('16:9');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string>('');
  const [showTopicPicker, setShowTopicPicker] = useState(false);
  const [customTopicInput, setCustomTopicInput] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const topicPickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        topicPickerRef.current &&
        !topicPickerRef.current.contains(event.target as Node)
      ) {
        setShowTopicPicker(false);
      }
    };

    if (showTopicPicker) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showTopicPicker]);
  const suggestedTopics = [
    'Design',
    'Architecture',
    'Engineering',
    'Systems',
    'Technology',
    'Philosophy',
    'Art',
    'Science',
    'Culture',
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleRemoveImage = () => {
    setSelectedImage(null);
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
      setImagePreview(null);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAddCustomTopic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTopicInput.trim()) return;
    const clean = customTopicInput.trim().replace(/^#+/, '');
    setSelectedTopic(clean);
    setCustomTopicInput('');
    setShowTopicPicker(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!bodyText.trim() && !selectedImage) || isSubmitting) return;

    setIsSubmitting(true);
    try {
      await createPost(bodyText.trim(), selectedImage, selectedTopic || undefined);
      setBodyText('');
      setSelectedTopic('');
      handleRemoveImage();
    } catch (err) {
      console.error('Failed to publish post:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800/90 p-4 shadow-xs transition-all focus-within:border-indigo-500">
      <form onSubmit={handleSubmit}>
        {/* Top: Avatar & Textarea */}
        <div className="flex gap-3.5 items-start">
          <div
            onClick={() => user && openUserProfile(user)}
            className="relative shrink-0 pt-0.5 cursor-pointer"
            title="Go to my profile"
          >
            {user?.photo ? (
              <img
                src={user.photo}
                alt={user.name || 'User'}
                referrerPolicy="no-referrer"
                className="h-10 w-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
              />
            ) : (
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-600 to-indigo-800 text-sm font-bold text-white shadow-inner">
                {user?.name?.charAt(0) || 'U'}
              </div>
            )}
          </div>

          <div className="flex-1">
            <textarea
              rows={2}
              placeholder={user ? `What's on your mind, ${user.name.split(' ')[0]}?` : "Share a thought, showcase a project..."}
              value={bodyText}
              onChange={(e) => setBodyText(e.target.value)}
              className="w-full resize-none bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
            />
          </div>
        </div>

        {/* Image Preview Container */}
        {imagePreview && (
          <div className="relative mt-3 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <img
              src={imagePreview}
              alt="Preview"
              className={`w-full object-cover max-h-[360px] ${
                aspectRatio === '16:9'
                  ? 'aspect-[16/9]'
                  : aspectRatio === '4:3'
                  ? 'aspect-[4/3]'
                  : aspectRatio === '1:1'
                  ? 'aspect-square'
                  : 'aspect-[9/16]'
              }`}
            />
            <button
              type="button"
              onClick={handleRemoveImage}
              className="absolute right-2.5 top-2.5 rounded-full bg-slate-950/80 p-1.5 text-white backdrop-blur hover:bg-slate-900 cursor-pointer"
              title="Remove image"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Aspect ratio control bar */}
            <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1 rounded-lg bg-slate-950/80 p-1 backdrop-blur-md text-[11px]">
              {(['16:9', '4:3', '1:1', '9:16'] as const).map((ratio) => (
                <button
                  key={ratio}
                  type="button"
                  onClick={() => setAspectRatio(ratio)}
                  className={`px-2 py-0.5 rounded font-mono transition-colors cursor-pointer ${
                    aspectRatio === ratio
                      ? 'bg-indigo-600 text-white font-medium'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {ratio}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Selected Topic Badge (Discretionary, clean, no hashtag) */}
        {selectedTopic && (
          <div className="mt-3 mb-1 flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/80 dark:border-indigo-800/80 px-3 py-1.5 text-xs font-medium text-indigo-700 dark:text-indigo-300 shadow-2xs">
              <Compass className="h-3.5 w-3.5 text-indigo-500" />
              <span>Topic: {selectedTopic}</span>
              <button
                type="button"
                onClick={() => setSelectedTopic('')}
                className="text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-200 cursor-pointer ml-1 p-0.5 rounded-md hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors"
                title="Remove topic"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          </div>
        )}

        {/* Bottom Toolbar & Action */}
        <div className="mt-3.5 flex items-center justify-between border-t border-slate-100 dark:border-slate-800/80 pt-3">
          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageChange}
              accept="image/*"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-pointer"
            >
              <ImageIcon className="h-4 w-4 text-indigo-500" />
              <span>Photo</span>
            </button>

            {/* Discretionary Topic Picker (No hashtags) */}
            <div className="relative" ref={topicPickerRef}>
              <button
                type="button"
                onClick={() => setShowTopicPicker(!showTopicPicker)}
                className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs transition-colors cursor-pointer ${
                  selectedTopic
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 font-semibold border border-indigo-200/80 dark:border-indigo-800/80'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Compass className="h-4 w-4 text-emerald-500" />
                <span>{selectedTopic || 'Topic'}</span>
              </button>

              {showTopicPicker && (
                <div className="absolute top-full mt-2.5 left-0 z-40 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 p-4 shadow-2xl space-y-3.5">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-1.5">
                      <Compass className="h-4 w-4 text-indigo-500" />
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-200 tracking-wide uppercase font-mono">
                        Select Topic
                      </span>
                    </div>
                    {selectedTopic && (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedTopic('');
                          setShowTopicPicker(false);
                        }}
                        className="text-xs font-semibold text-rose-500 hover:text-rose-600 hover:underline cursor-pointer transition-colors"
                      >
                        Clear Topic
                      </button>
                    )}
                  </div>

                  {/* Custom Topic Input */}
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Type custom topic (e.g. AI, Design)..."
                      value={customTopicInput}
                      onChange={(e) => setCustomTopicInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddCustomTopic(e);
                        }
                      }}
                      className="flex-1 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-3.5 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition-all"
                    />
                    <button
                      type="button"
                      onClick={handleAddCustomTopic}
                      disabled={!customTopicInput.trim()}
                      className="rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-40 cursor-pointer shrink-0 transition-colors shadow-xs"
                      title="Add custom topic"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* Suggested Topics List */}
                  <div>
                    <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 font-mono">
                      Suggested Topics
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {suggestedTopics.map((topic) => {
                        const isSelected = selectedTopic === topic;
                        return (
                          <button
                            key={topic}
                            type="button"
                            onClick={() => {
                              setSelectedTopic(isSelected ? '' : topic);
                              setShowTopicPicker(false);
                            }}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                                : 'bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white border border-transparent hover:border-slate-300 dark:hover:border-slate-600'
                            }`}
                          >
                            <span>{topic}</span>
                            {isSelected && <Check className="h-3.5 w-3.5" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={(!bodyText.trim() && !selectedImage) || isSubmitting}
            className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-500 disabled:opacity-50 disabled:pointer-events-none transition-all cursor-pointer whitespace-nowrap"
          >
            {isSubmitting ? (
              <span>Publishing...</span>
            ) : (
              <>
                <Send className="h-3.5 w-3.5" />
                <span>Publish Post</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
