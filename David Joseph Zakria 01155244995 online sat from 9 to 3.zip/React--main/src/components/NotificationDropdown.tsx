import React, { useState, useRef, useEffect } from 'react';
import { useNotifications } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { AppNotification } from '../types';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  UserCheck,
  CheckCheck,
  Trash2,
  ExternalLink,
  Sparkles,
  X,
  PlusCircle,
  Share2,
} from 'lucide-react';

interface NotificationDropdownProps {
  onClose?: () => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({ onClose }) => {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAllNotifications,
    simulateNotification,
  } = useNotifications();
  const { acceptFriendRequest, friendRequests, networkUsers } = useAuth();
  const { setActiveView, setSelectedPost, posts, openUserProfile } = usePosts();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [showSimulateOptions, setShowSimulateOptions] = useState(false);

  const displayedNotifications = filter === 'unread' 
    ? notifications.filter((n) => !n.read) 
    : notifications;

  const handleNotificationClick = (notif: AppNotification) => {
    markAsRead(notif.id);

    if (notif.type === 'friend_request' || notif.type === 'friend_accept') {
      setActiveView('friends');
    } else if (notif.type === 'like' || notif.type === 'comment' || notif.type === 'share') {
      if (notif.targetId) {
        const foundPost = posts.find((p) => p._id === notif.targetId);
        if (foundPost) {
          setSelectedPost(foundPost);
          setActiveView('post-details');
        } else {
          setActiveView('feed');
        }
      } else {
        setActiveView('feed');
      }
    }

    if (onClose) onClose();
  };

  const handleActorClick = (e: React.MouseEvent, actorId: string) => {
    e.stopPropagation();
    const actorUser = networkUsers.find((u) => u._id === actorId);
    if (actorUser) {
      openUserProfile(actorUser);
      if (onClose) onClose();
    }
  };

  const handleAcceptFriendInline = (e: React.MouseEvent, fromUserId: string) => {
    e.stopPropagation();
    const req = friendRequests.find((r) => r.fromUserId === fromUserId && r.status === 'pending');
    if (req) {
      acceptFriendRequest(req.id);
    } else {
      setActiveView('friends');
      if (onClose) onClose();
    }
  };

  const formatTimestamp = (isoString: string) => {
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const mins = Math.floor(diff / (1000 * 60));
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / (1000 * 60 * 60));
      if (hours < 24) return `${hours}h ago`;
      const days = Math.floor(hours / (1000 * 60 * 60 * 24));
      return `${days}d ago`;
    } catch {
      return 'Recently';
    }
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'like':
        return (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-white shadow-xs">
            <Heart className="h-3 w-3 fill-white" />
          </div>
        );
      case 'comment':
        return (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-cyan-500 text-white shadow-xs">
            <MessageCircle className="h-3 w-3" />
          </div>
        );
      case 'friend_request':
        return (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-indigo-600 text-white shadow-xs">
            <UserPlus className="h-3 w-3" />
          </div>
        );
      case 'friend_accept':
        return (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-white shadow-xs">
            <UserCheck className="h-3 w-3" />
          </div>
        );
      default:
        return (
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-indigo-500 text-white">
            <Sparkles className="h-3 w-3" />
          </div>
        );
    }
  };

  return (
    <div className="w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl backdrop-blur-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
      {/* Header */}
      <div className="p-4 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-slate-950/40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
              <Bell className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display">
              Notifications
            </h3>
            {unreadCount > 0 && (
              <span className="rounded-full bg-indigo-600 px-2 py-0.5 text-[10px] font-bold text-white font-mono">
                {unreadCount} new
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={markAllAsRead}
                className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors cursor-pointer"
                title="Mark all notifications as read"
              >
                <CheckCheck className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Mark read</span>
              </button>
            )}

            {notifications.length > 0 && (
              <button
                type="button"
                onClick={clearAllNotifications}
                className="p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
                title="Clear all"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Filter Pills */}
        <div className="mt-3 flex items-center gap-1 p-0.5 bg-slate-200/70 dark:bg-slate-800/70 rounded-xl text-xs font-semibold">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`flex-1 py-1 rounded-lg transition-all cursor-pointer ${
              filter === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            All ({notifications.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('unread')}
            className={`flex-1 py-1 rounded-lg transition-all cursor-pointer ${
              filter === 'unread'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Unread ({unreadCount})
          </button>
        </div>
      </div>

      {/* List */}
      <div className="max-h-[380px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
        {displayedNotifications.length > 0 ? (
          displayedNotifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif)}
              className={`group relative flex items-start gap-3 p-3.5 transition-colors cursor-pointer ${
                notif.read
                  ? 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  : 'bg-indigo-50/40 dark:bg-indigo-950/25 hover:bg-indigo-50/70 dark:hover:bg-indigo-950/40'
              }`}
            >
              {/* Unread indicator dot */}
              {!notif.read && (
                <div className="absolute left-1.5 top-5 h-2 w-2 rounded-full bg-indigo-600 shadow-sm" />
              )}

              {/* Avatar with Type Icon Badge */}
              <div
                className="relative shrink-0"
                onClick={(e) => handleActorClick(e, notif.actor._id)}
                title={`View ${notif.actor.name}'s profile`}
              >
                {notif.actor.photo ? (
                  <img
                    src={notif.actor.photo}
                    alt={notif.actor.name}
                    className="h-10 w-10 rounded-full object-cover ring-2 ring-white dark:ring-slate-800"
                  />
                ) : (
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-600 to-violet-700 text-xs font-bold text-white shadow-inner">
                    {notif.actor.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="absolute -bottom-1 -right-1">
                  {getIcon(notif.type)}
                </div>
              </div>

              {/* Content Details */}
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center justify-between gap-1">
                  <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {notif.actor.name}
                  </p>
                  <span className="text-[10px] text-slate-400 font-mono shrink-0">
                    {formatTimestamp(notif.createdAt)}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-snug break-words line-clamp-2">
                  {notif.message}
                </p>

                {/* Inline Actions for Friend Request */}
                {notif.type === 'friend_request' && !notif.read && (
                  <div className="pt-1.5 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => handleAcceptFriendInline(e, notif.actor._id)}
                      className="flex items-center gap-1 rounded-lg bg-indigo-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-indigo-500 shadow-xs transition-colors cursor-pointer"
                    >
                      <UserCheck className="h-3 w-3" />
                      <span>Accept Request</span>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleActorClick(e, notif.actor._id)}
                      className="rounded-lg bg-slate-100 dark:bg-slate-800 px-2 py-1 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
                    >
                      View Profile
                    </button>
                  </div>
                )}
              </div>

              {/* Delete action */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteNotification(notif.id);
                }}
                className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-500 rounded-md transition-opacity cursor-pointer"
                title="Remove notification"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        ) : (
          <div className="p-8 text-center space-y-2">
            <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400">
              <Bell className="h-5 w-5 opacity-60" />
            </div>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
            </p>
            <p className="text-[11px] text-slate-400 max-w-[220px] mx-auto">
              When someone likes your posts, adds comments, or sends friend requests, you will be notified here instantly.
            </p>
          </div>
        )}
      </div>

      {/* Footer Demo Trigger: Live Real-time Test */}
      <div className="p-2.5 bg-slate-50 dark:bg-slate-950/80 border-t border-slate-100 dark:border-slate-800/80">
        {!showSimulateOptions ? (
          <button
            type="button"
            onClick={() => setShowSimulateOptions(true)}
            className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-xl text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Test Real-Time Alert &rarr;</span>
          </button>
        ) : (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-semibold">
              <span>Send Live Test Event:</span>
              <button
                type="button"
                onClick={() => setShowSimulateOptions(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => {
                  simulateNotification('like');
                  setShowSimulateOptions(false);
                }}
                className="flex items-center justify-center gap-1 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-semibold border border-rose-200 dark:border-rose-900/40 hover:bg-rose-100 cursor-pointer"
              >
                <Heart className="h-3 w-3 fill-rose-500" /> Like
              </button>
              <button
                type="button"
                onClick={() => {
                  simulateNotification('comment');
                  setShowSimulateOptions(false);
                }}
                className="flex items-center justify-center gap-1 py-1 rounded-lg bg-cyan-50 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 font-semibold border border-cyan-200 dark:border-cyan-900/40 hover:bg-cyan-100 cursor-pointer"
              >
                <MessageCircle className="h-3 w-3" /> Reply
              </button>
              <button
                type="button"
                onClick={() => {
                  simulateNotification('friend_request');
                  setShowSimulateOptions(false);
                }}
                className="flex items-center justify-center gap-1 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-semibold border border-indigo-200 dark:border-indigo-900/40 hover:bg-indigo-100 cursor-pointer"
              >
                <UserPlus className="h-3 w-3" /> Request
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
