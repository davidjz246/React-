import React from 'react';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import {
  Home,
  Bookmark,
  Users,
  Flame,
  Image as ImageIcon,
} from 'lucide-react';

export const LeftSidebar: React.FC = () => {
  const { user, isAuthenticated, friends } = useAuth();
  const { activeView, setActiveView, posts } = usePosts();

  const savedCount = posts.filter((p) => p.isSaved).length;
  const topics = ['Architecture', 'DesignSystems', 'DeepWork', 'Philosophy', 'Engineering'];

  return (
    <aside className="sticky top-20 hidden md:flex flex-col gap-4 w-64 shrink-0">
      {/* Mini Profile Card */}
      {isAuthenticated && user && (
        <div
          onClick={() => setActiveView('profile')}
          className="group flex items-center gap-3 rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 p-3.5 hover:border-indigo-500/40 shadow-xs hover:shadow-sm transition-all cursor-pointer"
        >
          {user.photo ? (
            <img
              src={user.photo}
              alt={user.name}
              referrerPolicy="no-referrer"
              className="h-10 w-10 rounded-full object-cover ring-2 ring-indigo-500/20"
            />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-600 to-violet-700 font-bold text-white text-xs">
              {user.name?.charAt(0).toUpperCase() || 'U'}
            </div>
          )}

          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate transition-colors">
              {user.name}
            </p>
            <p className="text-[11px] text-slate-500 truncate">
              {user.handle || '@user'}
            </p>
          </div>
        </div>
      )}

      {/* Navigation Routes */}
      <div className="rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 p-3 space-y-1 text-xs font-semibold shadow-xs">
        <button
          type="button"
          onClick={() => setActiveView('feed')}
          className={`flex w-full items-center justify-between px-3 py-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'feed'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Home className="h-4 w-4" />
            <span>Discover Feed</span>
          </div>
          <span className="text-[11px] font-mono tabular-nums opacity-80">
            {posts.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('trending')}
          className={`flex w-full items-center justify-between px-3 py-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'trending'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Flame className="h-4 w-4 text-amber-500" />
            <span>Trending Posts</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('media')}
          className={`flex w-full items-center justify-between px-3 py-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'media'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <ImageIcon className="h-4 w-4 text-cyan-500" />
            <span>Visual Media</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('friends')}
          className={`flex w-full items-center justify-between px-3 py-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'friends'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Users className="h-4 w-4 text-emerald-500" />
            <span>Friends & Network</span>
          </div>
          {friends.length > 0 && (
            <span className="text-[11px] font-mono tabular-nums opacity-80">
              {friends.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveView('saved')}
          className={`flex w-full items-center justify-between px-3 py-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'saved'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Bookmark className="h-4 w-4 text-amber-500" />
            <span>Saved Posts</span>
          </div>
          {savedCount > 0 && (
            <span className="text-[11px] font-mono tabular-nums opacity-80">
              {savedCount}
            </span>
          )}
        </button>
      </div>

      {/* Featured Topics */}
      <div className="rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 p-4 space-y-2.5 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono px-1">
          Featured Topics
        </h3>
        <div className="flex flex-col gap-1">
          {topics.map((topic) => (
            <button
              key={topic}
              type="button"
              onClick={() => setActiveView('trending')}
              className="flex w-full items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all cursor-pointer text-left"
            >
              <span>{topic}</span>
              <span className="text-[11px] text-slate-400 font-mono px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800/80">
                Hot
              </span>
            </button>
          ))}
        </div>
      </div>
    </aside>
  );
};
