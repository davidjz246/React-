import React, { useState } from 'react';
import { Comment, User } from '../types';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostContext';
import { Heart, MoreHorizontal, Edit2, Trash2, Check, X } from 'lucide-react';

interface CommentItemProps {
  comment: Comment;
  postId: string;
}

export const CommentItem: React.FC<CommentItemProps> = ({ comment, postId }) => {
  const { user, networkUsers } = useAuth();
  const { updateComment, deleteComment, openUserProfile } = usePosts();
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(comment.content);
  const [showMenu, setShowMenu] = useState(false);
  const [isLiked, setIsLiked] = useState(comment.isLiked || false);
  const [likesCount, setLikesCount] = useState(comment.likesCount || 0);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const isAuthor =
    user && (user._id === comment.commentCreator._id || user.email === comment.commentCreator.email || (user.name && user.name === comment.commentCreator.name));

  const handleSaveEdit = async () => {
    if (!editContent.trim()) return;
    await updateComment(postId, comment._id, editContent.trim());
    setIsEditing(false);
  };

  const handleDelete = async () => {
    await deleteComment(postId, comment._id);
    setShowMenu(false);
  };

  const handleToggleLike = () => {
    setIsLiked(!isLiked);
    setLikesCount((prev) => (isLiked ? Math.max(0, prev - 1) : prev + 1));
  };

  const handleAuthorClick = () => {
    const existing = networkUsers.find((u) => u._id === comment.commentCreator._id);
    const creatorUser: User = existing || {
      _id: comment.commentCreator._id,
      name: comment.commentCreator.name,
      email: comment.commentCreator.email || '',
      photo: comment.commentCreator.photo,
      followersCount: 0,
      followingCount: 0,
    };
    openUserProfile(creatorUser);
  };

  const formatTime = (isoString?: string) => {
    if (!isoString) return 'Just now';
    try {
      const diff = Date.now() - new Date(isoString).getTime();
      const mins = Math.floor(diff / (1000 * 60));
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / (1000 * 60 * 60));
      if (hours < 24) return `${hours}h ago`;
      const days = Math.floor(hours / 24);
      return `${days}d ago`;
    } catch {
      return 'Recent';
    }
  };

  return (
    <div className="group relative flex gap-3 py-2.5 text-sm">
      {/* Avatar */}
      <div
        onClick={handleAuthorClick}
        className="relative shrink-0 cursor-pointer transition-transform hover:scale-105"
        title={`View ${comment.commentCreator.name}'s profile`}
      >
        {comment.commentCreator.photo ? (
          <img
            src={comment.commentCreator.photo}
            alt={comment.commentCreator.name || 'User'}
            referrerPolicy="no-referrer"
            className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-800"
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />
        ) : (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 dark:bg-indigo-950 font-semibold text-xs text-indigo-600 dark:text-indigo-300 ring-1 ring-indigo-500/20">
            {comment.commentCreator.name?.charAt(0).toUpperCase() || 'U'}
          </div>
        )}
      </div>

      {/* Content Container */}
      <div className="flex-1 min-w-0">
        <div className="relative rounded-xl bg-slate-50 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800/80 px-3.5 py-2.5 shadow-xs">
          {/* Header */}
          <div className="flex items-center justify-between gap-2 mb-1">
            <div className="flex items-center gap-2 text-xs">
              <span
                onClick={handleAuthorClick}
                className="font-semibold text-slate-900 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400 truncate cursor-pointer transition-colors"
              >
                {comment.commentCreator.name}
              </span>
              <span className="text-slate-400" aria-hidden="true">·</span>
              <span className="text-slate-400 tabular-nums">
                {formatTime(comment.createdAt)}
              </span>
            </div>

            {/* Author Menu */}
            {isAuthor && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowMenu(!showMenu)}
                  className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-opacity rounded cursor-pointer"
                  title="Comment actions"
                >
                  <MoreHorizontal className="h-3.5 w-3.5" />
                </button>

                {showMenu && (
                  <div className="absolute right-0 top-6 z-20 w-28 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 py-1 shadow-xl">
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditing(true);
                        setShowMenu(false);
                      }}
                      className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      <Edit2 className="h-3 w-3" /> Edit
                    </button>
                    {showDeleteConfirm ? (
                      <div className="p-2 m-1 space-y-1.5 bg-rose-50 dark:bg-rose-950/60 rounded-lg border border-rose-200 dark:border-rose-900">
                        <p className="text-[10px] font-semibold text-rose-600 dark:text-rose-300 text-center">
                          Delete comment?
                        </p>
                        <div className="flex gap-1.5">
                          <button
                            type="button"
                            onClick={handleDelete}
                            className="flex-1 rounded bg-rose-600 py-1 text-[10px] font-bold text-white hover:bg-rose-500 cursor-pointer"
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowDeleteConfirm(false)}
                            className="flex-1 rounded bg-slate-200 dark:bg-slate-700 py-1 text-[10px] font-medium text-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            No
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setShowDeleteConfirm(true)}
                        className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                      >
                        <Trash2 className="h-3 w-3" /> Delete
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Body or Edit Box */}
          {isEditing ? (
            <div className="space-y-2 mt-1">
              <textarea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                className="w-full rounded-md bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 p-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:border-indigo-500 focus:outline-none"
                rows={2}
                autoFocus
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditing(false);
                    setEditContent(comment.content);
                  }}
                  className="flex items-center gap-1 rounded px-2 py-1 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <X className="h-3 w-3" /> Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveEdit}
                  className="flex items-center gap-1 rounded bg-indigo-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-indigo-500 cursor-pointer"
                >
                  <Check className="h-3 w-3" /> Save
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300 break-words whitespace-pre-wrap">
              {comment.content}
            </p>
          )}
        </div>

        {/* Action Row */}
        {!isEditing && (
          <div className="flex items-center gap-3 mt-1 ml-2 text-[11px] text-slate-500">
            <button
              type="button"
              onClick={handleToggleLike}
              className={`flex items-center gap-1 transition-colors cursor-pointer ${
                isLiked ? 'text-rose-600 dark:text-rose-400 font-medium' : 'hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              <Heart
                className={`h-3 w-3 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`}
              />
              <span className="tabular-nums">{likesCount > 0 ? likesCount : 'Like'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
