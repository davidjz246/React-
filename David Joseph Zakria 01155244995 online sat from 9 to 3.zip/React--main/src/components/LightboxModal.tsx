import React from 'react';
import { X, Download } from 'lucide-react';

interface LightboxModalProps {
  imageUrl: string | null;
  onClose: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({ imageUrl, onClose }) => {
  if (!imageUrl) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-4 animate-in fade-in"
      onClick={onClose}
    >
      <div className="relative max-w-5xl max-h-[90vh] flex flex-col items-center" onClick={(e) => e.stopPropagation()}>
        {/* Top Controls */}
        <div className="absolute -top-12 right-0 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full bg-slate-900 border border-slate-700 p-2 text-slate-300 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Image */}
        <img
          src={imageUrl}
          alt="Expanded preview"
          referrerPolicy="no-referrer"
          className="max-h-[85vh] w-auto rounded-xl object-contain shadow-2xl ring-1 ring-slate-800"
        />
      </div>
    </div>
  );
};
